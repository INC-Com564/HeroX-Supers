function create(renderer, texture, lights, type) {
    var effect = renderer.createEffect("fiskheroes:wings");
    effect.texture.set(texture, lights);
    effect.anchor.set("rightArm");
    type.apply(effect);

    return {
        effect: effect,
        render: (entity, bladeUnfold) => {
            effect.unfold = type.timerFunc(entity);
            effect.bladeUnfold = bladeUnfold;
            effect.render();
        }
    };
}
