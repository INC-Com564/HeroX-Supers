var lengths = [1.9, 2.55, 2.675, 2.8, 2.9];

function create(renderer, anchor, energyColor) {
    var c1 = renderer.createEffect("fiskheroes:shield");
    c1.texture.set("cannon1", null);
    c1.anchor.set(anchor);
    c1.setRotation(3.0, 90.0, 3.0).setCurve(30.0, 136.0);
    c1.large = true;
    c1.mirror = true;

    var c2 = renderer.createEffect("fiskheroes:shield");
    c2.texture.set("cannon2", null);
    c2.anchor.set(anchor);
    c2.setRotation(-7.0, -90.0, 7.0).setCurve(60.0, 136.0);
    c2.large = true;
    c2.mirror = true;

    return {
        c1: c1,
        c2: c2,
        render: timer => {
            var f = Math.min(timer * 5, 1);
            c1.unfold = c2.unfold = timer;
            c1.setOffset(1.25, 6.3 + f * 2.0, 1.67 + f);
            c2.setOffset(1.25, 6.9 + f * 2.0, -1.67 - f);
            f = Math.min(timer * 5, 1);
            c1.render();
            c2.render();
        }
    };
}
