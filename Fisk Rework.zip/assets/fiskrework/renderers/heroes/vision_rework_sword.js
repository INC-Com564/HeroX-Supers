extend("fiskrework:vision_rework");
loadTextures({
    "layer1": "fiskrework:vision_sword_layer1.tx.json",
    "layer2": "fiskrework:vision_sword_layer2.tx.json",
    "cape": "fiskrework:vision_sword_cape.tx.json",
    "dense": "fiskrework:dense_sword_vision",
    "stone": "fiskheroes:vision_sword_stone",
    "stone_glow": "fiskheroes:vision_sword_stone",
    "lights": "fiskheroes:vision_sword_lights"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer === "HELMET" ? "lights" : null);
}

function getBeamColor() {
    return 0x40E7F9;
}
