extend("fiskrework:zoom_rework");
loadTextures({
    "eyes": "fiskheroes:zoom_concept_eyes"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "HELMET" && entity.getData("fiskheroes:speeding") ? "eyes" : "null");

    renderer.setItemIcons("%s_0", "zoom_rework_1", "zoom_rework_2", "zoom_rework_3");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    vibration = renderer.createEffect("fiskheroes:vibration");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskheroes:speeding") || entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
    }
}
