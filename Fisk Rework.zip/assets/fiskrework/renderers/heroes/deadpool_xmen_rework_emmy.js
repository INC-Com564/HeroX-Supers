extend("fiskrework:deadpool_xmen_rework");
loadTextures({
    "layer1": "fiskheroes:deadpool_xmen_emmy_layer1",
    "layer2": "fiskheroes:deadpool_xmen_emmy_layer2"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcons("deadpool_xmen_rework_0", "%s_1", "%s_2", "%s_3");
}
