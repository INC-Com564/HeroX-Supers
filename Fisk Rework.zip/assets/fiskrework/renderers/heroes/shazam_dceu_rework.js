extend("fiskheroes:hero_basic");
loadTextures({
    "billy_layer1": "fiskrework:null",
    "billy_layer2": "fiskrework:null",
    "shazam_layer1": "fiskheroes:shazam_dceu_layer1",
    "shazam_layer2": "fiskheroes:shazam_dceu_layer2",
    "lights": "fiskheroes:shazam_dceu_lights",
    "cape": "fiskheroes:shazam_dceu_cape"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");
var capes = implement("fiskheroes:external/capes");

var cape;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (entity.getData("fiskrework:dyn/shazam") || entity.is("DISPLAY")) {
            return renderLayer == "LEGGINGS" ? "shazam_layer2" : "shazam_layer1";
        }
        else if (entity.getData("fiskrework:dyn/shazam") == false) {
            return renderLayer == "LEGGINGS" ? "billy_layer2" : "billy_layer1";
        }
    });

    renderer.setLights((entity, renderLayer) => renderLayer == "CHESTPLATE" && (entity.getData("fiskrework:dyn/shazam") || entity.is("DISPLAY")) ? "lights" : null);

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.maxFlare = 0.4;
    cape = capes.createDefault(renderer, 17, "fiskheroes:cape_default.mesh.json", physics);
    cape.effect.texture.set("cape");
    cape.effect.width = 12;

    utils.bindParticles(renderer, "fiskrework:shazam_smoke");

    var beam = renderer.createResource("BEAM_RENDERER", "fiskrework:shazam_transform");

    transform = utils.createLines(renderer, beam, 0x88CBE6, [
        {
            "start": [0, -64, 0],
            "end": [0, -1, 0],
            "size": [15.0, 15.0]
        },
    ])
    
    transform.anchor.set("body");
    transform.setOffset(1.0, 38.0, -3.2).setRotation(0, 90.0, 0).setScale(15.0);
    transform.mirror = false;

    speedster.init(renderer, "fiskheroes:shazam");
    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0x88CBE6, [
        { "firstPerson": [-6.0, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:heat_vision", "fiskrework:shazam_beam", "rightArm", 0x88CBE6, [
        { "firstPerson": [-6.0, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] },
        { "firstPerson": [6.0, 4.5, -10.0], "offset": [0.5, 9.0, 0.0], "size": [0.75, 0.75], "anchor": "leftArm" }
    ]);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);

    addAnimationWithData(renderer, "shazam.LIGHTNING", "fiskheroes:dual_aiming", "fiskheroes:heat_vision_timer")
    .priority = -8;

    renderer.removeCustomAnimation("basic.HEAT_VISION");
    utils.addFlightAnimation(renderer, "shazam.FLIGHT", "fiskheroes:flight/default.anim.json");
    utils.addHoverAnimation(renderer, "shazam.HOVER", "fiskheroes:flight/idle/default");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE" && entity.getData("fiskrework:dyn/shazam") || entity.is("DISPLAY")) {
        cape.render(entity);
    }
    if (entity.getData("fiskrework:dyn/shazam_timer") > 0 && entity.getData("fiskrework:dyn/shazam_timer") < 1) {
        transform.render();
    }
}
