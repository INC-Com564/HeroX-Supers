extend("fiskrework:dark_archer_rework");
loadTextures({
    "layer1": "fiskrework:dark_archer_hand_layer1",
    "layer2": "fiskheroes:dark_archer_layer2",
    "pants_robes": "fiskheroes:dark_archer_pants_robes",
    "boots": "fiskheroes:dark_archer_boots",
    "arrow": "fiskheroes:arrow/dark_archer",
    "quiver": "fiskheroes:quiver/dark_archer"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);

    renderer.setItemIcon("HELMET", "dark_archer_rework_0");
    renderer.setItemIcon("LEGGINGS", "dark_archer_rework_2");
    renderer.setItemIcon("BOOTS", "dark_archer_rework_3");
}