extend("fiskheroes:hero_basic");
loadTextures({
    "base": "fiskheroes:iron_man_mk50",
    "suit": "fiskrework:iron_man_mk50_suit.tx.json",
    "mask": "fiskheroes:iron_man_mk50_mask.tx.json",
    "mask_lights": "fiskheroes:iron_man_mk50_mask_lights",
    "lights": "fiskheroes:iron_man_mk50_lights",
    "reactor": "fiskheroes:iron_man_mk50_reactor",
    "reactor_lights": "fiskheroes:iron_man_mk50_reactor_lights",
    "mega_shield": "fiskheroes:iron_man_mk50_shield",
    "mega_shield_lights": "fiskheroes:iron_man_mk50_shield_lights",
    "blade": "fiskheroes:iron_man_mk50_blade",
    "blade_lights": "fiskheroes:iron_man_mk50_blade_lights",
    "impale": "fiskrework:iron_man_mk50_impale",
    "shield": "fiskrework:iron_man_mk50_shield",
    "shield_lights": "fiskrework:iron_man_mk50_shield_lights",
    "cannon1": "fiskheroes:iron_man_mk50_cannon1",
    "cannon2": "fiskheroes:iron_man_mk50_cannon2",
    "cannon1_lights": "fiskheroes:iron_man_mk50_cannon1_lights",
    "cannon2_lights": "fiskheroes:iron_man_mk50_cannon2_lights",
    "cannon1_lights": "fiskheroes:iron_man_mk50_cannon1_lights",
    "cannon2_lights": "fiskheroes:iron_man_mk50_cannon2_lights",
    "cannon_inner": "fiskheroes:iron_man_mk50_cannon_inner",
    "repulsor": "fiskheroes:iron_man_repulsor",
    "repulsor_left": "fiskheroes:iron_man_repulsor_left",
    "repulsor_boots": "fiskheroes:iron_man_repulsor_boots",
    "cluster_cannon_anim": "fiskrework:cluster_cannon.tx.json",
    "cluster_cannon_light_anim": "fiskrework:cluster_cannon_lights.tx.json",
    "thruster_anim": "fiskrework:iron_man_mk50_thruster.tx.json",
    "thruster_light_anim": "fiskrework:iron_man_mk50_thruster_lights.tx.json",
});

var utils = implement("fiskheroes:external/utils");
var mk50_cannon = implement("fiskheroes:external/mk50_cannon");
var cluster_hands = implement("fiskrework:external/mk50_hand_cluster_cannon");
var iron_man_boosters = implement("fiskheroes:external/iron_man_boosters");
var foot_boost = implement("fiskrework:external/iron_man_mk50_boost");

var cannon;
var boosters;
var boost;

var repulsor;
var blade;
var impale;
var shield;
var cluster_cannon;
var hand_cluster;
var thruster;
var mega_shield;
var metal_heat;
var night_vision

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (entity.getData("fiskheroes:mask_open_timer2") > 0) {
            return "mask";
        }
        else if (!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") {
            var timer = entity.getInterpolatedData("fiskheroes:dyn/nanite_timer");
            return timer <= 0.5 ? "reactor" : timer < 1 ? "suit" : "base";
        }
        return "base";
    });
    renderer.setLights((entity, renderLayer) => {
        if (entity.getData("fiskheroes:mask_open_timer2") > 0) {
            return "mask_lights";
        }
        return (!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getInterpolatedData("fiskheroes:dyn/nanite_timer") < 1 ? "reactor_lights" : "lights";
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    repulsor = renderer.createEffect("fiskheroes:overlay");

    night_vision = renderer.bindProperty("fiskheroes:night_vision");
    night_vision.setCondition(entity => {
        night_vision.factor = (-0.4 + entity.getData("fiskheroes:dyn/nanite_timer") - entity.getData("fiskheroes:mask_open_timer2"));
        return true;
    });
    night_vision.fogStrength = 0.25;
    night_vision.firstPersonOnly = true;

    thruster = renderer.createEffect("fiskheroes:model");
    thruster.setModel(utils.createModel(renderer, "fiskrework:boot_thruster", "thruster_anim", "thruster_light_anim"));
    thruster.anchor.set("rightLeg");

    cluster_cannon = renderer.createEffect("fiskheroes:model");
    cluster_cannon.setModel(utils.createModel(renderer, "fiskrework:cluster_cannon", "cluster_cannon_anim", "cluster_cannon_light_anim"));
    cluster_cannon.anchor.set("head");

    blade = renderer.createEffect("fiskheroes:shield");
    blade.texture.set("blade", "blade_lights");
    blade.anchor.set("rightArm");
    blade.setOffset(1.5, 8.0, 0.0);
    blade.large = true;

    impale = renderer.createEffect("fiskheroes:shield");
    impale.texture.set("impale");
    impale.anchor.set("rightArm");

    mega_shield = renderer.createEffect("fiskheroes:shield");
    mega_shield.texture.set("mega_shield", "mega_shield_lights");
    mega_shield.anchor.set("rightArm");
    mega_shield.setRotation(0.0, 0.0, -10.0).setCurve(15.0, 50.0);
    mega_shield.large = true;

    shield = renderer.createEffect("fiskheroes:shield");
    shield.texture.set("shield", "shield_lights");
    shield.anchor.set("rightArm");
    shield.setRotation(0.0, 0.0, -10.0).setCurve(15.0, 35.0);
    shield.large = true;

    cannon = mk50_cannon.create(renderer, "rightArm", 0x00ACFF);
    hand_cluster = cluster_hands.create(renderer, "rightArm", 0x00ACFF);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);
    boost = foot_boost.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(blade, impale, shield, mega_shield, cannon.c1, cannon.c2, thruster);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    var shake = renderer.bindProperty("fiskheroes:camera_shake").setCondition(entity => {
        shake.factor = entity.isSprinting() && entity.getData("fiskheroes:flying") ? 0.3 * Math.sin(Math.PI * entity.getInterpolatedData("fiskheroes:flight_boost_timer")) : 0;
        return true;
    });
    shake.intensity = 0.05;

    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:heat_vision", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "fiskrework:iron_man_laser", "rightArm", 0xFF2211, [
        { "firstPerson": [-4.5, 3.25, -7.0], "offset": [-2.3, 9.0, 0.0], "size": [0.5, 0.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:mk50_cluster_cannon", "head", 0x00ACFF, [
        { "offset": [13.25, 5.0, 1.75], "size": [3.0, 0.5] },
        { "offset": [21.0, 5.0, -0.5], "size": [3.0, 0.5] },
        { "offset": [-13.75, 5.0, 1.75], "size": [3.0, 0.5] },
        { "offset": [-21.5, 5.0, -0.5], "size": [3.0, 0.5] },
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.0, 1.0], "anchor": "rightArm" },
        { "firstPerson": [4.5, 3.75, -7.0], "offset": [0.5, 9.0, 0.0], "size": [1.0, 1.0], "anchor": "leftArm" }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    utils.bindParticles(renderer, "fiskrework:mark_50").setCondition(entity => entity.getData("fiskheroes:flying"));
    renderer.bindProperty("fiskheroes:energy_bolt").color.set(0x00ACFF);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.AIMING");
    addAnimationWithData(renderer, "cannon.AIMING", "fiskheroes:aiming_fpcorr", "fiskheroes:aiming_timer").setCondition(entity => !entity.getData("fiskrework:dyn/laser_switch"));
    addAnimationWithData(renderer, "repulsor.AIMING", "fiskheroes:aiming", "fiskheroes:aiming_timer").setCondition(entity => entity.getData("fiskrework:dyn/laser_switch"));
    renderer.removeCustomAnimation("basic.ENERGY_PROJ");
    renderer.removeCustomAnimation("basic.HEAT_VISION");

    utils.addFlightAnimationWithLanding(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json").setCondition(entity => !entity.getData("fiskheroes:dyn/flight_super_boost"));
    utils.addFlightAnimationWithLanding(renderer, "iron_man.BOOST", "fiskrework:flight/mk50_boost.anim.json").setCondition(entity => entity.getData("fiskheroes:dyn/flight_super_boost"));
    utils.addHoverAnimation(renderer, "iron_man.HOVER", "fiskheroes:flight/idle/iron_man");
    utils.addAnimationEvent(renderer, "FLIGHT_DIVE", "fiskheroes:iron_man_dive");

    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;

    addAnimationWithData(renderer, "iron_man.ROLL", "fiskheroes:flight/barrel_roll", "fiskheroes:barrel_roll_timer").setCondition(entity => !entity.getData("fiskheroes:dyn/flight_super_boost"))
        .priority = 10;

    addAnimationWithData(renderer, "iron_man.BOOSTROLL", "fiskrework:flight/barrel_roll", "fiskheroes:barrel_roll_timer").setCondition(entity => entity.getData("fiskheroes:dyn/flight_super_boost"))
        .priority = 10;

    addAnimationWithData(renderer, "antimonitor.ANTIBLAST", "fiskheroes:aiming", "fiskheroes:energy_projection_timer");

    addAnimationWithData(renderer, "iron_man.TRANSFORM", "fiskrework:nanite_transform", "fiskheroes:dyn/nanite_timer");

    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming_fpcorr").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 3 - 2, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (entity.getData("fiskrework:dyn/laser_switch")) {
    repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
    repulsor.texture.set(null, "repulsor");
    repulsor.render();
    }
    else if (!entity.getData("fiskrework:dyn/laser_switch")) {
    repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer");
    repulsor.texture.set(null, "repulsor");
    repulsor.render();
    }
    repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer");
    repulsor.texture.set(null, "repulsor_left");
    repulsor.render();
    repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
    repulsor.texture.set(null, "repulsor_boots");
    repulsor.render();

    if (!entity.getData("fiskrework:dyn/weapon_switch") && entity.getData("fiskrework:dyn/slasher_timer")) {
    blade.unfold = entity.getInterpolatedData("fiskheroes:blade_timer");
    blade.render();
    }

    if (!entity.getData("fiskrework:dyn/weapon_switch") && entity.getData("fiskrework:dyn/impaler_timer")) {
    var f = Math.min(impale.unfold * 5, 1);
    impale.unfold = entity.getInterpolatedData("fiskheroes:blade_timer");
    impale.setOffset(2.9 + 0.1 * f, 6.0 + 3.0 * f, 0.0);
    impale.render();
    }

    if (entity.getData("fiskrework:dyn/weapon_switch") && entity.getData("fiskrework:dyn/circle_timer")) {
    shield.unfold = entity.getInterpolatedData("fiskheroes:shield_timer");
    shield.setOffset(2.9 + 1.8 * Math.min(shield.unfold * 3, 1), 6.0, 0.0);
    shield.render();
    }

    if (entity.getData("fiskrework:dyn/weapon_switch") && entity.getData("fiskrework:dyn/mega_timer")) {
    mega_shield.unfold = entity.getInterpolatedData("fiskheroes:shield_timer");
    mega_shield.setOffset(2.9 + 1.8 * Math.min(mega_shield.unfold * 3, 1), 6.0, 0.0);
    mega_shield.render();
    }

    if (!entity.getData("fiskrework:dyn/laser_switch")) {
    cannon.render(entity.getInterpolatedData("fiskheroes:aimed_timer"));
    }
    boosters.render(entity, renderLayer, isFirstPersonArm, true);
    boost.render(entity, renderLayer, isFirstPersonArm, true);
    hand_cluster.render(entity.getInterpolatedData("fiskheroes:beam_charge"));

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
    cluster_cannon.render();
    thruster.render();
}