extend("fiskrework:arsenal_rework");
loadTextures({
    "layer1": "fiskrework:arsenal_2040_layer1",
    "layer2": "fiskrework:arsenal_2040_layer2",
    "hood_down": "fiskrework:arsenal_2040_hood_down",
    "mask": "fiskrework:null",
    "quiver": "fiskrework:quiver/arsenal_2040"
});