extend("fiskheroes:spider_man_base");
loadTextures({
    "layer1": "fiskheroes:spider_man_raimi_layer1",
    "layer2": "fiskheroes:spider_man_raimi_layer2"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "layer2";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(0xE2062B);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    utils.addAnimationEvent(renderer, "WEBSWING_DEFAULT", "fiskheroes:swing_default2");
    utils.addAnimationEvent(renderer, "WEBSWING_TRICK_DEFAULT", "fiskheroes:swing_roll");

    addAnimationWithData(renderer, "spider.PERCH", "fiskrework:raimi_perch", "fiskrework:dyn/perch_timer")
        .priority = -10;
    addAnimationWithData(renderer, "spider.LAND", "fiskrework:spiderman_landing_raimi", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;

    addAnimation(renderer, "spider.MASK", "fiskrework:raimi_mask_toggle")
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0);
    });

    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
}
