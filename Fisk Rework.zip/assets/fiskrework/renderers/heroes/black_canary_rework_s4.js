extend("fiskrework:black_canary_rework");
loadTextures({
    "layer1": "fiskrework:black_canary_s4_layer1",
    "layer2": "fiskheroes:black_canary_layer2",
    "mask": "fiskrework:black_canary_s4_mask",
    "chest": "fiskheroes:black_canary_chest"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("HELMET", "black_canary_rework_0");
    renderer.setItemIcon("CHESTPLATE", "black_canary_rework_1");
    renderer.setItemIcon("LEGGINGS", "black_canary_rework_2");
    renderer.setItemIcon("BOOTS", "black_canary_rework_3");
}

function initEquipped(renderer) {
    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "rightLeg", "scale": 1.0, "offset": [-2.5, 1.0, 0.5], "rotation": [90.0, 180.0, -2.0] },
        { "anchor": "leftLeg", "scale": 1.0, "offset": [2.5, 1.0, 0.5], "rotation": [90.0, 180.0, 2.0] }
    ]);
}