extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:black_canary_dinah_layer1",
    "layer2": "fiskheroes:black_canary_dinah_layer2",
    "mask": "fiskheroes:black_canary_dinah_mask",
    "chest": "fiskheroes:black_canary_dinah_chest"
});

var utils = implement("fiskheroes:external/utils");

var chest;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE") {
            return entity.getWornHelmet().suitType() == $SUIT_NAME ? "layer1" : "chest";
        }
        return renderLayer == "HELMET" ? "mask" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });

    renderer.showModel("HELMET", "head", "headwear", "body");
}

function initEffects(renderer) {
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:canary_cry", "head", 0x211D1D, [
        { "firstPerson": [0, 2, 0], "offset": [0, 0, 0], "size": [2.5, 2.5] }
    ]);
    chest = renderer.createEffect("fiskheroes:chest");
    chest.setExtrude(1).setYOffset(1);

    initEquipped(renderer);
}

function initEquipped(renderer) {
    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "body", "scale": 0.635, "offset": [0, 4, 3.0], "rotation": [-136.0, 90.0, 0.0] }
    ]).slotIndex = 0;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        chest.render();
    }
}
