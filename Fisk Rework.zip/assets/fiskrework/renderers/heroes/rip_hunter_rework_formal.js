extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:rip_hunter_formal_layer1",
    "layer2": "fiskrework:rip_hunter_formal_layer2"
});

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:energy_bolt").color.set(0x005EFF);
}