extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:arrow_hood_layer1",
    "layer2": "fiskrework:arrow_hood_layer2",
    "hood_down": "fiskrework:arrow_hood_hood_down",
    "mask": "fiskrework:arrow_hood_mask",
    "paint": "fiskrework:arrow_hood_paint",
    "bow": "fiskrework:bow/arrow",
    "quiver": "fiskrework:quiver/arrow_s1",
    "arrow": "fiskrework:arrow/arrow_rework",
    "blank": "fiskrework:null"
});

var utils = implement("fiskheroes:external/utils");

var paint;
var mask;

function init(renderer) {
    parent.init(renderer);
        renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "hood_down";
        }
        return renderLayer == "HELMET" ? "blank" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
    
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");

    renderer.setItemIcon("BOOTS", "arrow_rework_3");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    utils.addLivery(renderer, "COMPOUND_BOW", "bow");
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "QUIVER", "quiver");

    paint = renderer.createEffect("fiskheroes:overlay");
    paint.texture.set("paint", null);
    mask = renderer.createEffect("fiskheroes:overlay");
    mask.texture.set("mask", null);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "arrow.HOOD", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "arrow.HOOD2", "fiskrework:remove_hood2")
    .setCondition(entity => !entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "HELMET" && !entity.is("DISPLAY")) {
      mask.render();
      mask.opacity = Math.max(0.5, 1.0 - (entity.getData("fiskrework:dyn/arrow_wet_timer")));
      paint.render();
      paint.opacity = Math.max(0.4, 0.75 - (entity.getData("fiskrework:dyn/arrow_wet_timer")));
  }
}
