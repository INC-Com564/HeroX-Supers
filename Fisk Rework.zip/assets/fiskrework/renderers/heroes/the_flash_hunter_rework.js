extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:the_flash_hunter_layer1",
    "layer2": "fiskheroes:the_flash_hunter_layer2"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("HELMET", "the_flash_jay_rework_0");
}

function initEffects(renderer) {
    vibration = renderer.createEffect("fiskheroes:vibration");

    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xFF4D00, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:wind_funnel", "rightArm", 0x3e3e3e, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);

    speedster.init(renderer, "fiskheroes:lightning_gold");
    utils.bindTrail(renderer, "fiskrework:flicker_gold").setCondition(entity => entity.getData("fiskheroes:slow_motion"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
    }
}