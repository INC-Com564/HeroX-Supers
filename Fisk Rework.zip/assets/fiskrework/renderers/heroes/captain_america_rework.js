extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:captain_america_layer1",
    "layer2": "fiskheroes:captain_america_layer2",
    "shield": "fiskrework:shields/captain_americas_shield",
    "damaged_shield": "fiskrework:shields/captain_americas_shield_cw"
});

var utils = implement("fiskheroes:external/utils");

var nbt
var equipment

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "layer2";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    var equipped = renderer.bindProperty("fiskheroes:equipped_item");
    equipped.setItems([
        { "anchor": "body", "scale": 1.0, "offset": [0.0, 5.0, 2.75], "rotation": [90.0, -180.0, 0.0] }
    ]);
    equipped.addOffset("QUIVER", -0.5, 0.0, 2.36);

    utils.addLivery(renderer, "SHIELD", "shield").setCondition(entity => entity.getHeldItem().damage() < 150 && getDamageOfEquipment(entity, 0) < 150);
    utils.addLivery(renderer, "SHIELD", "damaged_shield").setCondition(entity => entity.getHeldItem().damage() >= 150 || getDamageOfEquipment(entity, 0) >= 150);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "captain.MASK", "fiskheroes:remove_cowl")
        .setData((entity, data) => {
            var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
            data.load(f < 1 ? f : 0);
        });
}

function getDamageOfEquipment(entity, index) {
    var nbt = entity.getWornChestplate().nbt();
    var equipment = nbt.getTagList("Equipment");
    for (var i=0; i<equipment.tagCount(); i++) {
        if (equipment.getCompoundTag(i).getByte("Index") == index) {
            return equipment.getCompoundTag(i).getCompoundTag("Item").getShort("Damage");
        }
    }
    return 0.0;
}