extend("fiskrework:reverse_flash_rework");
loadTextures({
    "layer1": "fiskrework:reverse_flash_rework_earthx_layer1",
    "cowl": "fiskrework:reverse_flash_rework_earthx_cowl",
    "mask_anim": "fiskrework:reverse_flash_earthx_mask.tx.json",
    "mask_lights": "fiskrework:reverse_flash_earthx_lights_mask.tx.json"
});

var vibration;
var cowl

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });

    renderer.setItemIcon("LEGGINGS", "reverse_flash_rework_2");
    renderer.setItemIcon("BOOTS", "reverse_flash_rework_3");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    vibration = renderer.createEffect("fiskheroes:vibration");

    mask = renderer.createEffect("fiskheroes:overlay");
    mask.texture.set("mask", null);
    mask_anim = renderer.createEffect("fiskheroes:overlay");
    mask_anim.texture.set("mask_anim", null);
    mask_lights = renderer.createEffect("fiskheroes:overlay");
    mask_lights.texture.set(null, "mask_lights");

    cowl = renderer.createEffect("fiskheroes:overlay");
    cowl.texture.set("cowl", null);
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "HELMET") {
        if (entity.getInterpolatedData("fiskheroes:mask_open_timer2") > 0) {
          mask_anim.render();
          mask_anim.opacity = 0 + entity.getInterpolatedData("fiskheroes:mask_open_timer2")
          mask_lights.render();
          mask_lights.opacity = 0 + entity.getInterpolatedData("fiskheroes:mask_open_timer2")
        }
    }
    if (renderLayer == "HELMET") {
        cowl.render();
        cowl.opacity = 1 - entity.getInterpolatedData("fiskheroes:mask_open_timer2");
    }
    if (entity.getData("fiskheroes:mask_open") || entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
  }
}
