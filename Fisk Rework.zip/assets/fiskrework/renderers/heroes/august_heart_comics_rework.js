extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:august_heart_comics_layer1",
    "layer2": "fiskheroes:august_heart_comics_layer2",
    "pants": "fiskheroes:august_heart_comics_pants"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "LEGGINGS") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "layer2" : "pants";
        }
        return "layer1";
    });
}

function initEffects(renderer) {
    vibration = renderer.createEffect("fiskheroes:vibration");

    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0x9BFF38, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:speed_siphon_comic", "rightArm", 0xFFFF68, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [0.5, 0.5] }
    ]);

    speedster.init(renderer, "fiskheroes:lightning_comics_lime");
    utils.bindTrail(renderer, "fiskrework:flicker_comic_lime").setCondition(entity => entity.getData("fiskheroes:slow_motion"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
    }
}
