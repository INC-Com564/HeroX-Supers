extend("fiskrework:doctor_strange_rework");
loadTextures({
    "layer1": "fiskrework:doctor_strange_eye_layer1",
    "eye": "fiskrework:time_stone"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "CHESTPLATE" ? "eye" : null);

    renderer.setItemIcons("doctor_strange_0", "%s_1", "doctor_strange_rework_2", "doctor_strange_rework_3");
}
