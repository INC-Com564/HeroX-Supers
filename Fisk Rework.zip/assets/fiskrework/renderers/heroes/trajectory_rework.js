extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:trajectory_layer1",
    "layer2": "fiskheroes:trajectory_layer2"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var chest;

function initEffects(renderer) {
    chest = renderer.createEffect("fiskheroes:chest");
    chest.setExtrude(1).setYOffset(1);

    var trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskheroes:lightning_yellow"));
    trail.setCondition(entity => entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") <= 4);

    trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskheroes:lightning_trajectory"));
    trail.setCondition(entity => entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") > 4);

    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xFFD53A, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);

    speedster.init(renderer);
    utils.bindTrail(renderer, "fiskrework:flicker_yellow").setCondition(entity => entity.getData("fiskheroes:slow_motion") && entity.getData("fiskheroes:speed") <=4 );
    utils.bindTrail(renderer, "fiskrework:flicker_trajectory").setCondition(entity => entity.getData("fiskheroes:slow_motion") && entity.getData("fiskheroes:speed") > 4 );
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        chest.render();
    }
}
