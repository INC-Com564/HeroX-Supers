extend("fiskrework:spider_man_webb_rework");
loadTextures({
    "layer1": "fiskrework:spider_man_webb_rework_vigilante_layer1",
    "layer2": "fiskrework:spider_man_webb_rework_vigilante_layer2"
});
