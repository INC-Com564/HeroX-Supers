extend("fiskrework:savitar_rework");
loadTextures({
    "layer1_lights": "fiskheroes:savitar_rgb_layer1_lights.tx.json",
    "layer2_lights": "fiskheroes:savitar_rgb_layer2_lights.tx.json"
});

function getTrailType() {
    return "builtin/lightning_rgb_6";
}
