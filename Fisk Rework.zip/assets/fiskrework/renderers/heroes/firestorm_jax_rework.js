extend("fiskrework:firestorm_rework");
loadTextures({
    "layer1": "fiskheroes:firestorm_jax_layer1",
    "layer2": "fiskheroes:firestorm_jax_layer2",
    "lights": "fiskheroes:firestorm_jax_lights"
});
