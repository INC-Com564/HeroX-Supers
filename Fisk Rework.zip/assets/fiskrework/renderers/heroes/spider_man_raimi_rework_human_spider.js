extend("fiskrework:spider_man_raimi_rework");
loadTextures({
    "layer1": "fiskrework:spider_man_raimi_human_spider_layer1",
    "layer2": "fiskrework:spider_man_raimi_human_spider_layer2"
});
