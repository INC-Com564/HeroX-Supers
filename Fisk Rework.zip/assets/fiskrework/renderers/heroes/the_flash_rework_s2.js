extend("fiskrework:the_flash_rework");
loadTextures({
    "layer1": "fiskheroes:the_flash_s2_layer1",
    "layer2": "fiskheroes:the_flash_s1_layer2"
});
