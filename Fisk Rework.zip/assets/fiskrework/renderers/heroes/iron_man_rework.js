extend("fiskrework:iron_man_rework_base");
loadTextures({
    "layer1": "fiskheroes:iron_man_layer1",
    "layer2": "fiskheroes:iron_man_layer2",
    "lights_layer1": "fiskheroes:iron_man_lights_layer1",
    "lights_layer2": "fiskheroes:iron_man_lights_layer2",
    "lights_suit": "fiskheroes:iron_man_lights_suit.tx.json",
    "suit": "fiskheroes:iron_man_suit.tx.json",
    "mask": "fiskheroes:iron_man_helmet.tx.json",
    "mask_lights": "fiskheroes:iron_man_helmet_lights.tx.json"
});
