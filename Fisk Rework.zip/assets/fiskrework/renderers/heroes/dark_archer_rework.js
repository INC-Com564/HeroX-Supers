extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:dark_archer_layer1",
    "layer2": "fiskheroes:dark_archer_layer2",
    "pants_robes": "fiskheroes:dark_archer_pants_robes",
    "boots": "fiskheroes:dark_archer_boots",
    "arrow": "fiskheroes:arrow/dark_archer",
    "quiver": "fiskheroes:quiver/dark_archer"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "LEGGINGS") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "pants_robes" : "layer2";
        }
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "layer2";
        }
        return renderLayer == "BOOTS" ? "boots" : "layer1";
    });

    renderer.showModel("CHESTPLATE", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
}

function initEffects(renderer) {
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "QUIVER", "quiver");

    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "body", "scale": 0.6, "offset": [4.7, 10, -1], "rotation": [150.0, -175.0, -5.0] }
    ]);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "arrow.HOOD", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "arrow.HOOD2", "fiskrework:remove_hood2")
    .setCondition(entity => !entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });
}