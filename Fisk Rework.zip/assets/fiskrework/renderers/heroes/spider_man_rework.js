extend("fiskheroes:spider_man_base");
loadTextures({
    "layer1": "fiskheroes:spider_man_layer1",
    "layer2": "fiskrework:spider_man_rework_layer2",
    "web_wings": "fiskheroes:spider_man_wings",
    "eyes": "fiskrework:spider_man_eyes",
    "eyes_red": "fiskrework:spider_man_eyes_red"
});

var web_wings;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskrework:dyn/enhanced_combat") : entity.getData("fiskrework:dyn/enhanced_combat_timer") > 0)) {
            return "layer2";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    web_wings = renderer.createEffect("fiskheroes:wingsuit");
    web_wings.texture.set("web_wings");
    web_wings.opacity = 0.8;

    eyes = renderer.createEffect("fiskheroes:overlay");
    eyes.texture.set("eyes", null);
    eyes.opacity = 1;

    red_eyes = renderer.createEffect("fiskheroes:overlay");
    red_eyes.texture.set(null, "eyes_red");
    red_eyes.opacity = 1;

    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(0x00DAFF);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
		

    addAnimationWithData(renderer, "spider.PERCH", "fiskrework:mcu_perch", "fiskrework:dyn/perch_timer")
        .priority = -10;
    addAnimationWithData(renderer, "spider.LAND", "fiskrework:spiderman_landing_mcu", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;

    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
};

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        web_wings.unfold = entity.getInterpolatedData("fiskheroes:wing_animation_timer");
        web_wings.render();
    }
}

function render(entity, renderLayer) {
    if (renderLayer == "HELMET") {
        var eye_timer = entity.getData("fiskrework:dyn/enhanced_combat_timer");
        red_eyes.opacity = 1 * eye_timer;
        red_eyes.render();

        eyes.opacity = 1 - eye_timer
        eyes.render();
    }
}