extend("fiskrework:dark_archer_rework");
loadTextures({
    "layer1": "fiskrework:dark_archer_sarab_layer1",
    "layer2": "fiskheroes:dark_archer_layer2",
    "pants_robes": "fiskheroes:dark_archer_pants_robes",
    "boots": "fiskheroes:dark_archer_boots",
    "arrow": "fiskheroes:arrow/dark_archer",
    "quiver": "fiskheroes:quiver/dark_archer",
    "katana": "fiskrework:sarab_katana"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    
    renderer.setItemIcon("LEGGINGS", "dark_archer_rework_2");
    renderer.setItemIcon("BOOTS", "dark_archer_rework_3");
}

function initEffects(renderer) {
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "QUIVER", "quiver");
    utils.addLivery(renderer, "KATANA", "katana");
}