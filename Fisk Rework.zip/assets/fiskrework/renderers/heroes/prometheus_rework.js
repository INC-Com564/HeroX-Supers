extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:prometheus_rework_layer1",
    "layer2": "fiskheroes:prometheus_layer2",
    "mask": "fiskrework:prometheus_mask",
    "hood_down": "fiskrework:prometheus_hood_down",
    "sheath": "fiskheroes:prometheus_sheath",
    "bow": "fiskrework:bow/recurve",
    "arrow": "fiskheroes:arrow/prometheus",
    "quiver": "fiskheroes:quiver/prometheus"
});

var utils = implement("fiskheroes:external/utils");

var sheath;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "hood_down";
        }
        return renderLayer == "HELMET" ? "mask" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
    
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    sheath = renderer.createEffect("fiskheroes:model");
    sheath.setModel(utils.createModel(renderer, "fiskheroes:prometheus_sheath", "sheath"));
    sheath.anchor.set("body");

    utils.addLivery(renderer, "COMPOUND_BOW", "bow");
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "QUIVER", "quiver");

    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "body", "scale": 0.535, "offset": [-5.03, 1.28, 2.43], "rotation": [-150.0, 90.0, 0.0] }
    ]);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "arrow.HOOD", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "arrow.HOOD2", "fiskrework:remove_hood2")
    .setCondition(entity => !entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        sheath.render();
    }
}
