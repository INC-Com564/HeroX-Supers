extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:obsidian_layer1",
    "layer2": "fiskheroes:obsidian_layer2",
    "hood": "fiskheroes:obsidian_hood",
    "cape": "fiskheroes:obsidian_cape"
});

var utils = implement("fiskheroes:external/utils");
var capes = implement("fiskheroes:external/capes");

var cape;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "layer2" : "hood";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:opacity").setOpacity((entity, renderLayer) => {
        return 1 - Math.max(entity.getInterpolatedData("fiskheroes:teleport_timer"), entity.getInterpolatedData("fiskrework:dyn/partial_shadowform_timer")) * 0.6;
    });

    night_vision = renderer.bindProperty("fiskheroes:night_vision");
    night_vision.setCondition(entity => {
        night_vision.factor = (-0.2 + entity.getData("fiskheroes:lightsout_timer")) + entity.getData("fiskheroes:lightsout");
        // night_vision.factor = -0.6 + entity.getData("fiskheroes:shadowform_timer");
        // night_vision.factor = -0.75 + entity.getData("fiskrework:dyn/partial_shadowform_timer");
        return true;
    });
    night_vision.fogStrength = 0.25;
    night_vision.firstPersonOnly = true;

    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.maxFlare = 0.2;
    cape = capes.createDefault(renderer, 24, "fiskheroes:cape_default.mesh.json", physics);
    cape.effect.texture.set("cape");

    var chain = utils.bindCloud(renderer, "fiskheroes:telekinesis_chain", "fiskheroes:shadow_smoke");
    chain.anchor.set("rightArm");
    chain.setOffset(-0.5, 10.0, 0.0);
    chain.setFirstPerson(-4.75, 4.0, -8.5);

    utils.setOpacityWithData(renderer, 0.0, 1.0, "fiskheroes:shadowform_timer");
    utils.bindCloud(renderer, "fiskheroes:particle_cloud", "fiskheroes:shadow_smoke").setCondition(entity => entity.getData("fiskheroes:shadowform"));
    utils.bindParticles(renderer, "fiskrework:partial_shadow_smoke").setCondition(entity => entity.getData("fiskrework:dyn/partial_shadowform"));
    utils.bindParticles(renderer, "fiskrework:obsidian_teleport");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        cape.render(entity);
    }
}