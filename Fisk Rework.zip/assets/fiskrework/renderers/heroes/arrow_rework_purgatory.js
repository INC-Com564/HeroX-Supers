extend("fiskrework:arrow_rework_lian_yu");
loadTextures({
    "layer1": "fiskrework:arrow_purgatory_layer1",
    "layer2": "fiskrework:arrow_purgatory_layer2",
    "hood_down": "fiskrework:arrow_purgatory_hood_down",
    "mask": "fiskrework:null",
    "arrow": "fiskrework:arrow/lian_yu",
    "quiver": "fiskrework:quiver/arsenal_2040"
});