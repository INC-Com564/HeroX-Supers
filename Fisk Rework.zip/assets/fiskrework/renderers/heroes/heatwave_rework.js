extend("fiskheroes:hero_basic");
loadTextures({
    "jacket": "fiskheroes:heatwave_jacket",
    "pants": "fiskheroes:heatwave_pants",
    "boots": "fiskheroes:heatwave_boots",
    "heat_gun": "fiskrework:heat_gun.tx.json",
    "heat_gun_lights": "fiskrework:heat_gun_lights.tx.json",
    "cold_gun": "fiskrework:cold_gun.tx.json",
    "cold_gun_lights": "fiskrework:cold_gun_lights.tx.json"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => renderLayer == "LEGGINGS" ? "pants" : renderLayer == "BOOTS" ? "boots" : "jacket");

    renderer.showModel("CHESTPLATE", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
}

function initEffects(renderer) {
    var livery = renderer.bindProperty("fiskheroes:livery");
    livery.texture.set("heat_gun", "heat_gun_lights");
    livery.weaponType = "HEAT_GUN";

    var livery_cold = renderer.bindProperty("fiskheroes:livery");
    livery_cold.texture.set("cold_gun", "cold_gun_lights");
    livery_cold.weaponType = "COLD_GUN";

    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "rightLeg", "scale": 0.7, "offset": [-2.6, 0.5, 1.25], "rotation": [90.0, 0.0, 0.0] }
    ]).slotIndex = 0;
}