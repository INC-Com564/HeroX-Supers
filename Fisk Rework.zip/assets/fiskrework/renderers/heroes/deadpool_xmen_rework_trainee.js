extend("fiskrework:deadpool_xmen_rework");
loadTextures({
    "layer1": "fiskheroes:deadpool_xmen_trainee_layer1"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcons("deadpool_xmen_rework_0", "%s_1", "deadpool_xmen_rework_2", "deadpool_xmen_rework_3");
}
