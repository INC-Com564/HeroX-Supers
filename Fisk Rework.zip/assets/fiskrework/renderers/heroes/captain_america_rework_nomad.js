extend("fiskrework:captain_america_rework");
loadTextures({
    "layer1": "fiskheroes:captain_america_nomad_layer1",
    "layer2": "fiskheroes:captain_america_nomad_layer2",
    "shield": "fiskrework:shields/captain_americas_shield_nomad",
    "damaged_shield": "fiskrework:shields/captain_americas_shield_nomad_damaged"
});


function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("captain.MASK");
}