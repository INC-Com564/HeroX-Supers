extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:the_flash_test_layer1",
    "layer2": "fiskheroes:the_flash_test_layer2",
    "layer3": "fiskheroes:the_flash_test_layer3"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => renderLayer == "LEGGINGS" ? "layer2" : renderLayer == "BOOTS" ? "layer3" : "layer1");

    renderer.showModel("CHESTPLATE", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
}

function initEffects(renderer) {
    utils.setOpacityWithData(renderer, 0, 1, "fiskrework:dyn/speed_force_invis_timer");
    
    vibration = renderer.createEffect("fiskheroes:vibration");

    utils.bindParticles(renderer, "fiskrework:effect_clear");
    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskrework:lightning_blur", "rightArm", 0xCA0F2E, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:wind_funnel", "rightArm", 0x3e3e3e, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] },
        { "firstPerson": [4.5, 3.75, -7.0], "offset": [0.5, 9.0, 0.0], "size": [1.5, 1.5], "anchor": "leftArm" }
    ]);

    speedster.init(renderer, "fiskheroes:blur_red");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("flash.MASK");

    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible") || entity.getData("fiskrework:dyn/speed_force_invis_timer") > 0) {
        vibration.render();
    }
}