extend("fiskrework:spider_man_ps4_rework");
loadTextures({
    "layer1": "fiskrework:spider_man_ps4_damaged_classic_layer1",
    "layer2": "fiskrework:spider_man_ps4_damaged_classic_layer2"
});