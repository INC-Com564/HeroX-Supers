extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:vision_layer1.tx.json",
    "layer2": "fiskrework:vision_layer2.tx.json",
    "cape": "fiskrework:vision_cape.tx.json",
    "dense": "fiskrework:dense_vision",
    "stone": "fiskheroes:vision_stone",
    "stone_glow": "fiskheroes:vision_stone"
});

var utils = implement("fiskheroes:external/utils");
var capes = implement("fiskheroes:external/capes");

var cape;
var stone;
var stone_glow;
var layer1;
var layer2;
var dense;

function init(renderer) {
    parent.init(renderer);
}

function initEffects(renderer) {
    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.weight = 0.9;
    physics.maxFlare = 0.5;
    cape = capes.createDefault(renderer, 24, "fiskheroes:cape_default.mesh.json", physics);
    cape.effect.texture.set("cape");

    stone = renderer.createEffect("fiskheroes:overlay");
    stone.texture.set("stone", null);
    stone_glow = renderer.createEffect("fiskheroes:overlay");
    stone_glow.texture.set(null, "stone_glow");
    layer1 = renderer.createEffect("fiskheroes:overlay");
    layer1.texture.set("layer1", null);
    layer2 = renderer.createEffect("fiskheroes:overlay");
    layer2.texture.set("layer2", null);
    dense = renderer.createEffect("fiskheroes:overlay");
    dense.texture.set("dense", null);

    utils.setOpacityWithData(renderer, 0.5, 1.0, "fiskheroes:intangibility_timer");

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:charged_beam", "head", getBeamColor(), [
        { "firstPerson": [0.0, -6.15, 0.0], "offset": [0.0, -6.15, -4.0], "size": [1.0, 0.5] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:charged_beam", "head", getBeamColor(), [
        { "firstPerson": [0.0, -6.15, 0.0], "offset": [0.0, -6.15, -4.0], "size": [1.0, 0.5] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.AIMING");
    
    utils.addFlightAnimation(renderer, "vision.FLIGHT", "fiskheroes:flight/default.anim.json");
    utils.addHoverAnimation(renderer, "vision.HOVER", "fiskheroes:flight/idle/neutral");
}

function getBeamColor() {
    return 0xFFFF6D;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            stone_glow.opacity = (entity.getInterpolatedData("fiskheroes:beam_charge") || entity.getInterpolatedData("fiskheroes:aiming_timer"));
            stone.render();
            stone_glow.render();
        }
        else if (renderLayer == "CHESTPLATE" && entity.getData("fiskrework:dyn/disguise_timer") < 1) {
            cape.render(entity);
        }
    }
    if (entity.isWearingFullSuit() && entity.getData("fiskrework:dyn/disguise_timer") > 0) {
            layer1.render();
            layer2.render();
    }
    if (entity.isWearingFullSuit() && entity.getData("fiskrework:dyn/dense_timer") > 0) {
            dense.opacity = (entity.getInterpolatedData("fiskrework:dyn/dense_timer"));
            dense.render();
    }
}
