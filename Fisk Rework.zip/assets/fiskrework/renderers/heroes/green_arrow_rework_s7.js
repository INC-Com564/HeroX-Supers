extend("fiskrework:green_arrow_rework");
loadTextures({
    "layer1": "fiskrework:green_arrow_s7_layer1",
    "layer2": "fiskheroes:green_arrow_s5_layer2",
    "quiver": "fiskheroes:quiver/green_arrow_s5",
    "hood_down": "fiskrework:green_arrow_s7_hood_up",
    "mask": "fiskrework:null"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("CHESTPLATE", "green_arrow_rework_s5_1");
    renderer.setItemIcon("LEGGINGS", "green_arrow_rework_s5_2");
    renderer.setItemIcon("BOOTS", "green_arrow_rework_s5_3");
}