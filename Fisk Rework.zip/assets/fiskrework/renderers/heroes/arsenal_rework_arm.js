extend("fiskrework:arsenal_rework");
loadTextures({
    "layer1": "fiskrework:arsenal_arm_layer1",
    "hood_down": "fiskrework:arsenal_arm_hood_down",
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcons("arsenal_rework_0", "%s_1", "arsenal_rework_2", "arsenal_rework_3");
}