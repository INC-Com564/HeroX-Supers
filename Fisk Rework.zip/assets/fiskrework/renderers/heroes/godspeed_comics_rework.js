extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:godspeed_comics_layer1",
    "layer2": "fiskheroes:godspeed_comics_layer2",
    "layer1_on": "fiskheroes:godspeed_comics_layer1_on",
    "layer2_on": "fiskheroes:godspeed_comics_layer2_on",
    "lights": "fiskheroes:godspeed_comics_lights",
    "lights_layer1": "fiskheroes:godspeed_comics_lights_layer1",
    "lights_layer2": "fiskheroes:godspeed_comics_lights_layer2"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;
var ears;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => (renderLayer == "LEGGINGS" ? "layer2" : "layer1") + (entity.getData("fiskheroes:speeding") ? "_on" : ""));
    renderer.setLights((entity, renderLayer) => {
        if (entity.getData("fiskheroes:speeding")) {
            return renderLayer == "LEGGINGS" ? "lights_layer2" : "lights_layer1";
        }
        return renderLayer == "CHESTPLATE" ? "lights" : null;
    });
}

function initEffects(renderer) {
    ears = renderer.createEffect("fiskheroes:ears");
    ears.anchor.set("head");
    ears.angle = 15;
    ears.inset = 0.025;

    vibration = renderer.createEffect("fiskheroes:vibration");
    
    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xFFFF68, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:speed_siphon_comic", "rightArm", 0xFFFF68, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [0.5, 0.5] }
    ]);

    speedster.init(renderer, "fiskheroes:lightning_comics_yellow");
    utils.bindTrail(renderer, "fiskrework:flicker_comic_yellow").setCondition(entity => entity.getData("fiskheroes:slow_motion"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "HELMET") {
        ears.render();
    }
    else if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
    }
}
