extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:citizen_steel_layer1",
    "layer2": "fiskheroes:citizen_steel_layer2",
    "metal_helm": "fiskheroes:citizen_steel_metal",
    "metal": "fiskrework:citizen_steel_metal_no_helm"
});

var metal_helm;
var metal;
var metal_helm_heat;
var metal_heat;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "layer2";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    metal_helm = renderer.createEffect("fiskheroes:overlay");
    metal_helm.texture.set("metal_helm");

    metal_helm_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_helm_heat.texture.set("metal_helm");

    metal = renderer.createEffect("fiskheroes:overlay");
    metal.texture.set("metal");

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.texture.set("metal");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "captain.MASK", "fiskheroes:remove_cowl")
        .setData((entity, data) => {
            var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
            data.load(f < 1 ? f : 0);
        });
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((renderLayer == "HELMET" || renderLayer == "CHESTPLATE") && entity.getData("fiskheroes:mask_open_timer2") < 0.35) {
        metal_helm.opacity = entity.getInterpolatedData("fiskheroes:dyn/steel_timer");
        metal_helm.render();

        metal_helm_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
        metal_helm_heat.render();
    }

    if ((renderLayer == "HELMET" || renderLayer == "CHESTPLATE") && entity.getData("fiskheroes:mask_open_timer2") > 0.35) {
        metal.opacity = entity.getInterpolatedData("fiskheroes:dyn/steel_timer");
        metal.render();

        metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
        metal_heat.render();
    }
}
