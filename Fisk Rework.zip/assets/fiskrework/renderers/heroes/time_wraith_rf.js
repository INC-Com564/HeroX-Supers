extend("fiskrework:time_wraith");
loadTextures({
	"layer1": "fiskrework:time_wraith_rf_layer1",
	"layer2": "fiskrework:time_wraith_rf_layer2"
});

var utils = implement("fiskheroes:external/utils");

var ribcage;
var leftArm;
var rightArm;

function init(renderer) {
    parent.init(renderer);
}

function initEffects(renderer) {
	parent.initEffects(renderer);

    var trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskrework:wraith_red"));
    trail.setCondition(entity => (entity.getData("fiskheroes:dyn/flight_super_boost") > 0));

    ribcage = renderer.createEffect("fiskheroes:model");
    ribcage.setModel(utils.createModel(renderer, "fiskrework:timewraith_ribcage", "ribCage"));
    ribcage.anchor.set("body");

    leftArm = renderer.createEffect("fiskheroes:model");
    leftArm.setModel(utils.createModel(renderer, "fiskrework:timewraith_leftarm", "leftArm"));
    leftArm.anchor.set("leftArm");
    
    rightArm = renderer.createEffect("fiskheroes:model");
    rightArm.setModel(utils.createModel(renderer, "fiskrework:timewraith_rightarm", "rightArm"));
    rightArm.anchor.set("rightArm");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "CHESTPLATE") {
        rightArm.render();
    }
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        ribcage.render();
        leftArm.render();
    }
}