extend("fiskrework:green_arrow_rework");
loadTextures({
    "layer1": "fiskrework:green_arrow_rework_s4_layer1",
    "layer2": "fiskheroes:green_arrow_s4_layer2",
    "quiver": "fiskheroes:quiver/green_arrow_s4",
    "hood_down": "fiskrework:green_arrow_s4_hood_down",
    "mask": "fiskrework:green_arrow_s4_mask"
});