extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:black_lightning_layer1",
    "layer2": "fiskheroes:black_lightning_layer2",
    "layer1_lights": "fiskheroes:black_lightning_layer1_lights",
    "layer2_lights": "fiskheroes:black_lightning_layer2_lights",
    "visor": "fiskheroes:black_lightning_visor"
});

var utils = implement("fiskheroes:external/utils");
var beam = implement("fiskrework:external/trail_beam_utils");

var overlay;
var night_vision

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "LEGGINGS" ? "layer2_lights" : "layer1_lights");
}

function initEffects(renderer) {
    utils.setOpacityWithData(renderer, 0, 1, "fiskrework:dyn/invis_timer");

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set("visor");

    utils.bindParticles(renderer, "fiskheroes:black_lightning").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0x0049FF, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:lightning_discharge", "rightArm", 0x0049FF, [
        { "firstPerson": [-6.0, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] },
        { "firstPerson": [6.0, 4.5, -10.0], "offset": [0.5, 9.0, 0.0], "size": [0.75, 0.75], "anchor": "leftArm" }
    ]);

    night_vision = renderer.bindProperty("fiskheroes:night_vision").setCondition(entity => (entity.getData("fiskrework:dyn/goggles")));
    night_vision.factor = 0.50;
    night_vision.firstPersonOnly = true;

    beam.init(renderer, "fiskrework:black_lightning");

    var trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskrework:lightning_shield"));
    trail.setCondition(entity => (entity.getData("fiskheroes:shield")));

    var chain = utils.bindCloud(renderer, "fiskheroes:telekinesis_chain", "fiskrework:lightning_chain");
    chain.anchor.set("rightArm");
    chain.setOffset(-0.5, 10.0, 0.0);
    chain.setFirstPerson(-4.75, 4.0, -8.5);

    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0x0049FF);
    forcefield.setShape(18, 18).setOffset(0.0, 6.0, 0.0).setScale(1.25);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.15;
        return true;
    });

}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
    utils.addFlightAnimation(renderer, "lightning.FLIGHT", "fiskheroes:flight/propelled_hands.anim.json");
    utils.addHoverAnimation(renderer, "lightning.HOVER", "fiskheroes:flight/idle/propelled_hands");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "HELMET") {
        overlay.opacity = 1 - 0.7 * entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        overlay.render();
    }
}
