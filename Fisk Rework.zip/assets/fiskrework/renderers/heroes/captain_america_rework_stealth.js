extend("fiskrework:captain_america_rework");
loadTextures({
    "layer1": "fiskheroes:captain_america_stealth_layer1",
    "layer2": "fiskheroes:captain_america_stealth_layer2",
    "damaged_shield": "fiskrework:shields/captain_americas_shield_stealth_damaged"
});

var utils = implement("fiskheroes:external/utils");

function initEffects(renderer) {
    parent.initEffects(renderer);
    utils.addLivery(renderer, "SHIELD", "shield");
}
