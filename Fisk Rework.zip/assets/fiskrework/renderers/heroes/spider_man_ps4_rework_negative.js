extend("fiskheroes:spider_man_base");
loadTextures({
    "layer1": "fiskrework:spider_man_ps4_negative_layer1",
    "layer2": "fiskrework:spider_man_ps4_negative_layer2",
    "lights_layer1": "fiskrework:spider_man_ps4_negative_lights_layer1",
    "lights_layer2": "fiskrework:spider_man_ps4_negative_lights_layer2"
});

var utils = implement("fiskheroes:external/utils");

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(0x00DAFF);

    renderer.setLights((entity, renderLayer) => renderLayer == "LEGGINGS" ? "lights_layer2" : "lights_layer1");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "spider.LAND", "fiskrework:spiderman_landing_ps4", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;

    utils.addAnimationEvent(renderer, "WEBSWING_TRICK_RIGHT", [
        "fiskheroes:swing_rotate_right", "fiskheroes:swing_rotate_right1"
    ]);
    utils.addAnimationEvent(renderer, "WEBSWING_TRICK_LEFT", [
        "fiskheroes:swing_rotate_left", "fiskheroes:swing_rotate_left1"
    ]);

    addAnimationWithData(renderer, "spider.PERCH", "fiskrework:ps4_perch", "fiskrework:dyn/perch_timer")
    .priority = -10;

    addAnimationWithData(renderer, "spider.CLING", "fiskrework:ps4_cling1", "fiskheroes:flying")
    .priority = -10;

    renderer.reprioritizeDefaultAnimation("PUNCH", 9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", 9);
}
