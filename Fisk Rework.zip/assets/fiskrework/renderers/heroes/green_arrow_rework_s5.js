extend("fiskrework:green_arrow_rework");
loadTextures({
    "layer1": "fiskrework:green_arrow_rework_s5_layer1",
    "layer2": "fiskheroes:green_arrow_s5_layer2",
    "quiver": "fiskheroes:quiver/green_arrow_s5",
    "hood_down": "fiskrework:green_arrow_s5_hood_down",
    "mask": "fiskrework:green_arrow_s5_mask"
});