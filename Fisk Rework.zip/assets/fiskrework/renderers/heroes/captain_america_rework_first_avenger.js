extend("fiskrework:captain_america_rework");
loadTextures({
    "layer1": "fiskrework:captain_america_war_layer1",
    "layer2": "fiskrework:captain_america_war_layer2",
    "strap": "fiskrework:captain_america_war_strap",
    "shield": "fiskrework:shields/captain_americas_shield",
    "damaged_shield": "fiskrework:shields/captain_americas_shield_war",
    "ammo": "fiskrework:war_bag"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
}

function initEffects(renderer) {
    utils.addLivery(renderer, "SHIELD", "shield").setCondition(entity => entity.getHeldItem().damage() < 150 && getDamageOfEquipment(entity, 0) < 150);
    utils.addLivery(renderer, "SHIELD", "damaged_shield").setCondition(entity => entity.getHeldItem().damage() >= 150 || getDamageOfEquipment(entity, 0) >= 150);
    utils.addLivery(renderer, "AMMO_BAG", "ammo");

    var equipped = renderer.bindProperty("fiskheroes:equipped_item");
    equipped.setItems([
        { "anchor": "body", "scale": 1.0, "offset": [0.0, 5.0, 3.25], "rotation": [90.0, -180.0, 0.0] }
    ]);
    equipped.addOffset("QUIVER", -0.5, 0.0, 2.36);
}

function getDamageOfEquipment(entity, index) {
    var nbt = entity.getWornChestplate().nbt();
    var equipment = nbt.getTagList("Equipment");
    for (var i=0; i<equipment.tagCount(); i++) {
        if (equipment.getCompoundTag(i).getByte("Index") == index) {
            return equipment.getCompoundTag(i).getCompoundTag("Item").getShort("Damage");
        }
    }
    return 0.0;
}