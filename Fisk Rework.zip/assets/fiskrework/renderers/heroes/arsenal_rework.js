extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:arsenal_rework_layer1",
    "layer2": "fiskheroes:arsenal_layer2",
    "hood_down": "fiskrework:arsenal_hood_down",
    "mask": "fiskrework:arsenal_mask",
    "bow": "fiskrework:bow/arsenal",
    "arrow": "fiskheroes:arrow/arsenal",
    "quiver": "fiskheroes:quiver/arsenal"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "hood_down";
        }
        return renderLayer == "HELMET" ? "mask" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
    
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    utils.addLivery(renderer, "COMPOUND_BOW", "bow");
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "QUIVER", "quiver");

    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "rightLeg", "scale": 0.6, "offset": [-2.9, 6.5, 1.25], "rotation": [0.0, 0.0, 0.0] },
        { "anchor": "leftLeg", "scale": 0.6, "offset": [2.0, 6.5, 1.25], "rotation": [0.0, 0.0, 0.0] }
    ]).slotIndex = 0;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "arrow.HOOD", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "arrow.HOOD2", "fiskrework:remove_hood2")
    .setCondition(entity => !entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });
}