extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:the_flash_jay_layer1",
    "layer2": "fiskheroes:the_flash_jay_layer2"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
}

function initEffects(renderer) {
    vibration = renderer.createEffect("fiskheroes:vibration");

    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xFF4D00, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:speed_siphon", "body", 0xFF0000, [
        { "firstPerson": [0, 7, 0.0], "offset": [0, 3.5, 0.0], "size": [0.75, 0.75] }
    ]);

    speedster.init(renderer, "fiskheroes:lightning_gold");
    utils.bindTrail(renderer, "fiskrework:flicker_gold").setCondition(entity => entity.getData("fiskheroes:slow_motion"));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible")) {
        vibration.render();
    }
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
}
