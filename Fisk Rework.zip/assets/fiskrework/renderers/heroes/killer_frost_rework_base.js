extend("fiskheroes:hero_basic");
loadTextures({
    "icicle": "fiskheroes:killer_frost_icicle",
    "eyes": "fiskrework:killer_frost_eyes"
});

var utils = implement("fiskheroes:external/utils");

var chest;
var overlay;
var spikeL;
var spikeR;

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("HELMET", "head", "headwear", "body", "rightArm", "leftArm");
}

function initEffects(renderer) {
    chest = renderer.createEffect("fiskheroes:chest");
    chest.setExtrude(0.75).setYOffset(1);

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set("hands", "eyes");
    overlay.opacity = 0.8;

    spikeL = renderer.createEffect("fiskheroes:shield");
    spikeL.texture.set("icicle");
    spikeL.anchor.set("rightArm");
    spikeL.setRotation(0.0, 0.0, -3.125).setCurve(20.0, 90.0);
    spikeR = renderer.createEffect("fiskheroes:shield");
    spikeR.texture.set("icicle");
    spikeR.anchor.set("rightArm");
    spikeR.setRotation(0.0, 180.0, -3.125).setCurve(20.0, 90.0);

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:frost_blast", "rightArm",  0x4CB5FF, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] },
        { "firstPerson": [4.5, 3.75, -7.0], "offset": [0.5, 9.0, 0.0], "size": [1.5, 1.5], "anchor": "leftArm" }
      ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskrework:killer_frost_beam_ice"));;

    utils.bindParticles(renderer, "fiskheroes:killer_frost_ice").setCondition(entity => entity.getData("fiskheroes:cryo_charging"));
    utils.bindParticles(renderer, "fiskheroes:killer_frost_ice").setCondition(entity => entity.getData("fiskrework:dyn/cryo"));
    utils.bindParticles(renderer, "fiskheroes:killer_frost_ice").setCondition(entity => entity.getData("fiskheroes:beam_charging"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "HELMET") {
        var charge = (entity.getData("fiskheroes:cryo_charge") || entity.getData("fiskrework:dyn/cryo_timer"));
        overlay.opacity = 0.8 * charge;
        overlay.render();

        spikeL.unfold = spikeR.unfold = entity.getInterpolatedData("fiskheroes:blade_timer") * (entity.isBookPlayer() ? 1 : Math.sqrt(charge));

        var f = Math.min(spikeL.unfold * 5, 1);
        spikeL.setOffset(2.25 + 1.0 * f, 8.0 + 2.0 * f, 0.0);
        spikeR.setOffset(-0.25 - 1.0 * f, 8.0 + 2.0 * f, 0.0);
        spikeL.render();
        spikeR.render();

        if (!isFirstPersonArm) {
            chest.render();
        }
    }
}