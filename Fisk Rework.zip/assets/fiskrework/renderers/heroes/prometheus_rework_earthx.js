extend("fiskrework:prometheus_rework");
loadTextures({
    "layer1": "fiskrework:prometheus_rework_earthx_layer1",
    "layer2": "fiskheroes:prometheus_earthx_layer2",
    "mask": "fiskrework:prometheus_earthx_mask",
    "hood_down": "fiskrework:prometheus_earthx_hood_down",
    "quiver": "fiskheroes:quiver/prometheus_earthx"
});
