extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:black_panther_layer1",
    "layer2": "fiskheroes:black_panther_layer2",
    "claws": "fiskheroes:black_panther_claws"
});

var overlay;
var night_vision;

function initEffects(renderer) {
    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set("claws");

    night_vision = renderer.bindProperty("fiskheroes:night_vision");
    night_vision.factor = 0.4;
    night_vision.fogStrength = 0.25;
    night_vision.firstPersonOnly = true;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "CHESTPLATE" && entity.getData("fiskheroes:blade")) {
        overlay.render();
    }
}
