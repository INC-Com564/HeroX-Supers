extend("fiskrework:captain_america_rework");
loadTextures({
    "layer1": "fiskheroes:captain_america_aou_layer1",
    "layer2": "fiskheroes:captain_america_aou_layer2",
    "shield": "fiskrework:shields/captain_americas_shield",
    "damaged_shield": "fiskrework:shields/captain_americas_shield_aou"
});
