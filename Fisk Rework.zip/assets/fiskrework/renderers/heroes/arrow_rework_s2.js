extend("fiskrework:arrow_rework");
loadTextures({
    "layer1": "fiskrework:arrow_hood_layer1",
    "layer2": "fiskrework:arrow_hood_layer2",
    "hood_down": "fiskrework:arrow_hood_hood_down",
    "mask": "fiskrework:arrow_mask",
    "bow": "fiskrework:bow/arrow",
    "quiver": "fiskrework:quiver/arrow_s1"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("HELMET", "arrow_rework_0");
    renderer.setItemIcon("CHESTPLATE", "arrow_rework_s1_1");
    renderer.setItemIcon("LEGGINGS", "arrow_rework_s1_2");
    renderer.setItemIcon("BOOTS", "arrow_rework_3");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    utils.addLivery(renderer, "COMPOUND_BOW", "bow");
}