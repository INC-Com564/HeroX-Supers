extend("fiskrework:deadpool_xmen_rework");
loadTextures({
    "layer1": "fiskrework:deadpool_3_layer1",
    "layer2": "fiskrework:deadpool_3_layer2",
    "scabbard": "fiskheroes:deadpool_xmen_scabbard",
    "katana": "fiskrework:deadpool_3_katana",
    "gun": "fiskrework:deadpool_3_gun"
});
