extend("fiskrework:the_flash_rework");
loadTextures({
    "layer1": "fiskheroes:the_flash_earthx_layer1",
    "layer2": "fiskheroes:the_flash_earthx_layer2"
});
