extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:wild_dog_makeshift_layer1",
    "layer2": "fiskrework:wild_dog_makeshift_layer2"
});

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "body", "scale": 0.7, "offset": [-3.8, 4.25, 0.5], "rotation": [110.0, 180.0, 0.5] },
        { "anchor": "body", "scale": 0.7, "offset": [3.8, 4.25, 0.5], "rotation": [110.0, 180.0, -0.5] }
    ]);
}
