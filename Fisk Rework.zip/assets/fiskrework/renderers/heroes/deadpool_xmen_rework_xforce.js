extend("fiskrework:deadpool_xmen_rework");
loadTextures({
    "layer1": "fiskheroes:deadpool_xmen_xforce_layer1",
    "layer2": "fiskheroes:deadpool_xmen_xforce_layer2"
});
