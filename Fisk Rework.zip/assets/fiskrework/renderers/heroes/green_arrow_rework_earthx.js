extend("fiskrework:green_arrow_rework");
loadTextures({
    "layer1": "fiskrework:green_arrow_rework_earthx_layer1",
    "layer2": "fiskheroes:green_arrow_earthx_layer2",
    "quiver": "fiskheroes:quiver/green_arrow_earthx",
    "bow": "fiskrework:bow/earthx",
    "arrow": "fiskrework:arrow/earthx_rework",
    "hood_down": "fiskrework:green_arrow_earth_x_hood_down",
    "hood": "fiskrework:green_arrow_earth_x_hood",
    "mask": "fiskrework:green_arrow_earth_x_mask",
    "mask_anim": "fiskrework:dark_arrow_mask.tx.json",
    "mask_lights": "fiskrework:dark_arrow_lights_mask.tx.json"
});

var utils = implement("fiskheroes:external/utils");

var hood;
var hood_down;
var mask;
var mask_anim;
var mask_lights;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    utils.addLivery(renderer, "ARROW", "arrow");
    utils.addLivery(renderer, "COMPOUND_BOW", "bow");

    mask = renderer.createEffect("fiskheroes:overlay");
    mask.texture.set("mask", null);
    mask_anim = renderer.createEffect("fiskheroes:overlay");
    mask_anim.texture.set("mask_anim", null);
    mask_lights = renderer.createEffect("fiskheroes:overlay");
    mask_lights.texture.set(null, "mask_lights");

    hood = renderer.createEffect("fiskheroes:overlay");
    hood.texture.set("hood", null);
    hood_down = renderer.createEffect("fiskheroes:overlay");
    hood_down.texture.set("hood_down", null);
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "HELMET") {
        if (entity.getInterpolatedData("fiskheroes:mask_open_timer2") > 0) {
          mask_anim.render();
          mask_anim.opacity = 1 - entity.getInterpolatedData("fiskheroes:mask_open_timer2")
          mask_lights.render();
          mask_lights.opacity = 1 - entity.getInterpolatedData("fiskheroes:mask_open_timer2")
        }else {
            mask.render();
        }
    }
    if (renderLayer == "CHESTPLATE") {
        if (entity.getInterpolatedData("fiskheroes:mask_open_timer2") > 0.35) {
          hood_down.render();
        }else {
          hood.render();
    }  
  }
}
