extend("fiskrework:falcon_rework");
loadTextures({
    "layer1": "fiskrework:falcon_winter_soldier_layer1",
    "layer2": "fiskrework:falcon_winter_soldier_layer2",
    "wings": "fiskrework:falcon_winter_soldier_wings",
    "jetpack": "fiskrework:falcon_winter_soldier_jetpack",
    "jetpack_lights": "fiskheroes:falcon_civil_war_jetpack_lights"
});

function initBoosters(renderer, utils, falcon_boosters) {
    utils.bindParticles(renderer, "fiskheroes:falcon_cw").setCondition(entity => entity.getData("fiskheroes:flying"));
    return falcon_boosters.create(renderer, 0xFF0000, "fiskheroes:red_fire_layer_%s", {
        boosters: [
            { anchor: "body", offset: [2.4, 5.0, 2.6], rotation: [0.0, -18.0, 0.0], size: [1.75, 3.0], mirror: true }
        ],
        bloom: [
            { anchor: "body", offset: [2.4, 5.0, 2.6], rotation: [0.0, -18.0, 0.0], size: [1.75, 1.75, 6.0], mirror: true }
        ]
    });
}

function getFlightAnimation() {
    return "fiskheroes:flight/falcon_with_arms.anim.json";
}
