extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:savitar_layer1",
    "layer2": "fiskheroes:savitar_layer2",
    "layer1_lights": "fiskheroes:savitar_layer1_lights",
    "layer2_lights": "fiskheroes:savitar_layer2_lights",
    "metal": "fiskheroes:savitar_metal",
    "spike": "fiskheroes:savitar_spike"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var utils = implement("fiskheroes:external/utils");

var vibration;
var spike;
var metal_heat;

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "LEGGINGS" ? "layer2_lights" : "layer1_lights");
}

function initEffects(renderer) {
    utils.setOpacityWithData(renderer, 0, 1, "fiskrework:dyn/speed_force_invis_timer");

    spike = renderer.createEffect("fiskheroes:shield");
    spike.texture.set("spike");
    spike.anchor.set("rightArm");
    spike.setRotation(0.0, 0.0, 10.0).setCurve(40.0, 160.0);
    spike.mirror = true;

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(spike);
    metal_heat.texture = "metal";

    vibration = renderer.createEffect("fiskheroes:vibration");

    utils.bindParticles(renderer, "fiskrework:effect_clear");
    utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xE0FFFF, [
        { "firstPerson": [-6, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:wind_funnel", "rightArm", 0x3e3e3e, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] },
        { "firstPerson": [4.5, 3.75, -7.0], "offset": [0.5, 9.0, 0.0], "size": [1.5, 1.5], "anchor": "leftArm" }
    ]);

    speedster.init(renderer, getTrailType());
    utils.bindTrail(renderer, "fiskrework:flicker_white").setCondition(entity => entity.getData("fiskheroes:slow_motion"));
}

function getTrailType() {
    return "fiskheroes:lightning_white";
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);

    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:invisible") || entity.getData("fiskheroes:intangible") || entity.getData("fiskrework:dyn/speed_force_invis_timer") > 0) {
        vibration.render();
    }
    else if (renderLayer == "CHESTPLATE") {
        spike.unfold = entity.getInterpolatedData("fiskheroes:blade_timer");

        var f = Math.min(spike.unfold * 5, 1);
        spike.setOffset(2.9 + 0.6 * f, 6.0 + 2.0 * f, 0.0);
        spike.render();
    }

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}