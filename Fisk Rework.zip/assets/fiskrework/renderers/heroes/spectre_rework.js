extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:spectre_layer1",
    "layer2": "fiskheroes:spectre_layer2",
    "layer1_cloak": "fiskheroes:spectre_layer1_cloak",
    "layer2_cloak": "fiskheroes:spectre_layer2_cloak",
    "arrow_layer1": "fiskrework:green_arrow_rework_layer1",
    "arrow_layer2": "fiskheroes:green_arrow_layer2",
    "quiver": "fiskheroes:quiver/green_arrow",
    "mask": "fiskrework:green_arrow_mask",
    "arrow_hood_down": "fiskrework:green_arrow_hood_down",
    "cloak": "fiskheroes:spectre_cloak",
    "eyes": "fiskrework:spectre_eyes",
    "spectre_arrow": "fiskrework:arrow/spectre",
    "arrow_lights": "fiskrework:arrow/spectre_lights"
});

var utils = implement("fiskheroes:external/utils");

var glow;
var overlay;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (entity.getData("fiskrework:dyn/arrow_timer") < 0.5) {
            if (entity.getWornHelmet().suitType() == $SUIT_NAME) {
                return renderLayer == "HELMET" ? "cloak" : renderLayer == "LEGGINGS" ? "layer2_cloak" : "layer1_cloak";
            }
            return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
        }
        if (entity.getData("fiskrework:dyn/arrow_timer") > 0.5 && entity.isWearingFullSuit()) {
            if (renderLayer == "CHESTPLATE" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
                return "arrow_hood_down";
            }
            return renderLayer == "HELMET" ? "mask" : renderLayer == "LEGGINGS" ? "arrow_layer2" : "arrow_layer1";
        }
    })
    
    renderer.setLights((entity, renderLayer) => renderLayer == "HELMET" && entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:mask_open_timer2") > 1 && !entity.getData("fiskrework:dyn/arrow") ? "eyes" : null);

    renderer.showModel("HELMET", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
}

function initEffects(renderer) {
    utils.addLivery(renderer, "QUIVER", "quiver").setCondition(entity => entity.getData("fiskrework:dyn/arrow"));

    var livery = renderer.bindProperty("fiskheroes:livery").setCondition(entity => entity.getData("fiskrework:dyn/arrow_empower"));
    livery.texture.set("spectre_arrow", "arrow_lights");
    livery.weaponType = "ARROW";

    glow = renderer.createEffect("fiskheroes:glowerlay");
    glow.color.set(0x0f6b29);

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set(null, "eyes");
    overlay.opacity = 1;

    utils.bindCloud(renderer, "fiskheroes:teleportation", "fiskheroes:breach");
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "fiskrework:energy_projection", "body", 0x0022FF, [
        { "firstPerson": [0.0, 6.0, 0.0], "offset": [0.0, 5.0, -4.0], "size": [4.0, 4.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0x0022FF);
    forcefield.setShape(18, 18).setOffset(0.0, 6.0, 0.0).setScale(1.25);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.15;
        return true;
    });
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "flash.MASK", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getData("fiskrework:dyn/arrow"))
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });
}

function render(entity, renderLayer) {
    glow.opacity = Math.sin(Math.PI *entity.getInterpolatedData("fiskrework:dyn/arrow_timer"));
    glow.render();

    if (renderLayer == "HELMET" && !entity.getData("fiskrework:dyn/arrow")) {
        var eyes = entity.getData("fiskheroes:mask_open_timer2");
        overlay.opacity = 1 * eyes;
        overlay.render();
    }
}