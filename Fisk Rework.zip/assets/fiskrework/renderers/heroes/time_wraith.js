extend("fiskheroes:hero_basic");
loadTextures({
	"layer1": "fiskrework:time_wraith_layer1",
	"layer2": "fiskrework:time_wraith_layer2",
  "ribCage": "fiskrework:time_wraith_skeleton",
  "leftArm": "fiskrework:time_wraith_skeleton",
  "rightArm": "fiskrework:time_wraith_skeleton"
});

var utils = implement("fiskheroes:external/utils");

var ribcage;
var leftArm;
var rightArm;

function init(renderer) {
    parent.init(renderer);
}

function initEffects(renderer) {
  	parent.initEffects(renderer);

    var trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskrework:wraith_orange"));
    trail.setCondition(entity => (entity.getData("fiskheroes:dyn/flight_super_boost") > 0));

    ribcage = renderer.createEffect("fiskheroes:model");
    ribcage.setModel(utils.createModel(renderer, "fiskrework:timewraith_ribcage", "ribCage"));
    ribcage.anchor.set("body");

    leftArm = renderer.createEffect("fiskheroes:model");
    leftArm.setModel(utils.createModel(renderer, "fiskrework:timewraith_leftarm", "leftArm"));
    leftArm.anchor.set("leftArm");
    
    rightArm = renderer.createEffect("fiskheroes:model");
    rightArm.setModel(utils.createModel(renderer, "fiskrework:timewraith_rightarm", "rightArm"));
    rightArm.anchor.set("rightArm");

    renderer.bindProperty("fiskheroes:opacity").setOpacity((entity, renderLayer) => {
        return 0.9999 ;
    });
    utils.bindParticles(renderer, "fiskrework:time_wraith_smoke").setCondition(entity => entity.getData("fiskheroes:flying"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    utils.addFlightAnimation(renderer, "vision.FLIGHT", "fiskheroes:flight/default.anim.json");
    utils.addHoverAnimation(renderer, "vision.HOVER", "fiskheroes:flight/idle/neutral");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "CHESTPLATE") {
        rightArm.render();
    }
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        ribcage.render();
        leftArm.render();
    }
}