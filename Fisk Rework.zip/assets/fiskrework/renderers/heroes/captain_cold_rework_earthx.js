extend("fiskheroes:hero_basic");
loadTextures({
    "jacket": "fiskrework:captain_cold_earthx_jacket",
    "jacket_pants": "fiskrework:captain_cold_earthx_jacket_pants",
    "pants": "fiskrework:captain_cold_earthx_pants",
    "pants_jacket": "fiskrework:captain_cold_earthx_pants_jacket",
    "boots": "fiskrework:captain_cold_earthx_boots",
    "lights": "fiskrework:captain_cold_earthx_lights",
    "cold_gun": "fiskrework:cold_gun.tx.json",
    "cold_gun_lights": "fiskrework:cold_gun_lights.tx.json",
    "heat_gun": "fiskrework:heat_gun.tx.json",
    "heat_gun_lights": "fiskrework:heat_gun_lights.tx.json"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE") {
            return entity.getWornLeggings().suitType() == $SUIT_NAME ? "jacket_pants" : "jacket";
        }
        else if (renderLayer == "LEGGINGS") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "pants_jacket" : "pants";
        }
        return "boots";
    });
    renderer.setLights((entity, renderLayer) => {
        return (renderLayer == "HELMET" && entity.getWornLeggings().suitType() == $SUIT_NAME ||
            renderLayer == "HELMET" && entity.getWornChestplate().suitType() != $SUIT_NAME) ? "lights" : null
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    var livery = renderer.bindProperty("fiskheroes:livery");
    livery.texture.set("cold_gun", "cold_gun_lights");
    livery.weaponType = "COLD_GUN";

    var livery_heat = renderer.bindProperty("fiskheroes:livery");
    livery_heat.texture.set("heat_gun", "heat_gun_lights");
    livery_heat.weaponType = "HEAT_GUN";

    utils.bindBeam(renderer, "fiskheroes:cold_gun", "fiskheroes:cold_beam", "rightArm", 0x4CB5FF, [
        { "firstPerson": [-4.75, 3.0, -13.0], "offset": [-0.6, 19.0, -1.5], "size": [2.0, 2.0] }
    ]);
    
    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "rightLeg", "scale": 0.7, "offset": [-2.6, 0.5, 1.25], "rotation": [90.0, 0.0, 0.0] }
    ]).slotIndex = 0;
}
