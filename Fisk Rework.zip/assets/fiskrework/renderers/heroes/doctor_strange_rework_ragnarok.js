extend("fiskrework:doctor_strange_rework");
loadTextures({
    "layer1": "fiskrework:doctor_strange_ragnarok_layer1"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcons("doctor_strange_0", "%s_1", "doctor_strange_rework_2", "doctor_strange_rework_3");
}
