extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskrework:green_arrow_rework_layer1",
    "layer2": "fiskheroes:green_arrow_layer2",
    "quiver": "fiskheroes:quiver/green_arrow",
    "hood_down": "fiskrework:green_arrow_hood_down",
    "mask": "fiskrework:green_arrow_mask"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "CHESTPLATE" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "hood_down";
        }
        return renderLayer == "HELMET" ? "mask" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
    
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm");
    renderer.fixHatLayer("HELMET", "CHESTPLATE");
}

function initEffects(renderer) {
    utils.addLivery(renderer, "QUIVER", "quiver");

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskrework:bow_flash", "rightArm", 0xFF0000, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [0.5, 0.5] }
    ]);

    utils.bindParticles(renderer, "fiskrework:bow_flash").setCondition(entity => entity.getData("fiskheroes:beam_shooting_timer") > 0);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "arrow.HOOD", "fiskheroes:remove_cowl")
    .setCondition(entity => entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "arrow.HOOD2", "fiskrework:remove_hood2")
    .setCondition(entity => !entity.getHeldItem().isEmpty())
    .setData((entity, data) => {
        var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
        data.load(f < 1 ? f : 0.0);
    });

    addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 5 - 4, 0)));
}