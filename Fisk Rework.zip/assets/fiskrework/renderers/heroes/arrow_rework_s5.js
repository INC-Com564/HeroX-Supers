extend("fiskrework:arrow_rework_s1");
loadTextures({
    "hood_down": "fiskrework:arrow_kapiushon_hood_down",
    "mask": "fiskrework:null",
    "paint": "fiskrework:null",
    "quiver": "fiskrework:quiver/arrow_s1"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("HELMET", "arrow_rework_purgatory_0");
    renderer.setItemIcon("CHESTPLATE", "arrow_rework_s1_1");
    renderer.setItemIcon("LEGGINGS", "arrow_rework_s1_2");
    renderer.setItemIcon("BOOTS", "arrow_rework_3");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    utils.addLivery(renderer, "COMPOUND_BOW", "bow");
}