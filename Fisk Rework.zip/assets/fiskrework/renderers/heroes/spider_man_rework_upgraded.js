extend("fiskrework:spider_man_rework");
loadTextures({
    "layer1": "fiskheroes:spider_man_upgraded_layer1",
    "layer2": "fiskrework:spider_man_rework_upgraded_layer2",
    "eyes": "fiskrework:spider_man_eyes_stark"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setItemIcon("HELMET", "spider_man_rework_stark_0");
}
