extend("fiskrework:spider_man_rework");
loadTextures({
    "layer1": "fiskheroes:spider_man_stark_layer1",
    "layer2": "fiskrework:spider_man_rework_stark_layer2",
    "eyes": "fiskrework:spider_man_eyes_stark"
});
