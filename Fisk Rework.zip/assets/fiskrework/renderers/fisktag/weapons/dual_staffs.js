loadTextures({
    "base":      "fiskrework:staff"
});

var utils = implement("fisktag:external/utils");

var model;

function init(renderer) {
    model = utils.createModel(renderer, "fiskrework:staff", "base");
    renderer.setModel(model);
}

function render(renderer, entity, glProxy, renderType, scopeTimer, recoil, isLeftSide) {
    glProxy.translate(0, -0.7, -0.1);

    glProxy.scale(0.7);
}
