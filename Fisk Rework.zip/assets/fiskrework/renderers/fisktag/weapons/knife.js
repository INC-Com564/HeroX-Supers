loadTextures({
    "base":      "fiskrework:knife"
});

var utils = implement("fisktag:external/utils");

var model;

function init(renderer) {
    model = utils.createModel(renderer, "fiskrework:knife", "base");
    renderer.setModel(model);
}

function render(renderer, entity, glProxy, renderType, scopeTimer, recoil, isLeftSide) {
    glProxy.translate(-0.1, -0.1, -0.1);

    glProxy.scale(1);
}
