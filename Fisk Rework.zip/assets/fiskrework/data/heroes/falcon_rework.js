var super_boost = implement("fiskheroes:external/super_boost_with_cooldown");
var falcon_base = implement("fiskheroes:external/falcon_base");

function init(hero) {
    hero.setName("hero.fiskheroes.falcon.name");
    hero.setVersion("Rework")
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.goggles");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskheroes:exo7_flightpack");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.3, 1);
    hero.addPrimaryEquipment("fiskheroes:beretta_93r{Dual:1,display:{Name:\"Dual Steyr SPP's\",Lore:[\"\u00A77Damage \u00A7c50%\",\"\u00A77Firerate \u00A763600 \u00A77rpm\",\"\u00A77Accurarcy \u00A76\u00A7l\u00A7n+\u00A762.36 \u00A77degrees\",\"\u00A77Recoil \u00A760.75 \u00A77degrees\",\"\u00A77Range \u00A7650 \u00A77blocks\",\" \",\"\u00A77Reload Time \u00A7e0.8\u00A77s\"]}}", true, item => item.nbt().getBoolean("Dual"));

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("SHIELD", "key.wingShield", 2);
    hero.addKeyBindFunc("AUTO", cycleMode, "Trigger Automatic Fire/Single Shot", 3);

    super_boost = super_boost.create(200, 150, 20);
    falcon_base.init(hero, super_boost, 2, 0.25, (entity, manager) => {
        if (entity.getData("fiskheroes:shield") || entity.getData("fiskheroes:blade")) {
            manager.setData(entity, "fiskheroes:flying", false);
        }
    });
    hero.setRuleValueModifier(ruleModifier);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
}

function ruleModifier(entity, rule) {
    var beretta = entity.getHeldItem().name() == "fiskheroes:beretta_93r";
    var auto = entity.getHeldItem().nbt().getByte("Mode") == 0;

    if (beretta && auto && rule.name() == "fiskheroes:cooldown_beretta93r") {
		return rule.value() - 18
	}
    if (beretta && auto && rule.name() == "fiskheroes:dmgmult_beretta93r") {
		return rule.value() - 0.3
	}
    if (rule.name() == "fiskheroes:range_beretta93r") {
		return rule.value() - 25
	}
    if (beretta && auto && rule.name() == "fiskheroes:spread_beretta93r") {
		return rule.value() + 0.8
	}
    if (beretta && auto && rule.name() == "fiskheroes:recoil_beretta93r") {
		return rule.value() + 0.35
	}
    return null;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        return (entity.getData("fiskheroes:flight_timer") > 0 || !entity.getData("fiskheroes:shield")) && super_boost.isModifierEnabled(entity, modifier);
    case "fiskheroes:shield":
        return !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    default:
        return true;
    }
}

function cycleMode(entity, manager) {
    var isBurst = entity.getHeldItem().nbt().getBoolean("Mode")
    if (!isBurst) {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", true)
        entity.playSound("fiskheroes:item.gun.beretta.switch", 1.0, 1.0)
    } else {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", false)
        entity.playSound("fiskheroes:item.gun.beretta.switch", 1.0, 1.0)
    }
    return true;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "SHIELD":
        return entity.getHeldItem().isEmpty() && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "AUTO":
        return entity.getHeldItem().name() == "fiskheroes:beretta_93r" && !entity.getData("fiskheroes:aiming");
    default:
        return super_boost.isKeyBindEnabled(entity, keyBind);
    }
}

function canAim(entity) {
    return entity.getHeldItem().isGun();
}
