function init(hero) {
    hero.setName("hero.fiskheroes.captain_cold.name");
    hero.setAliases("cap_cold");
    hero.setVersion("Rework")
    hero.setTier(1);

    hero.setHelmet("item.superhero_armor.piece.goggles");
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:cold_gun", true);

    hero.addPowers("fiskheroes:cold_resistance");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.0, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBindFunc("CRYO", cryoTrigger, "Trigger Cryo Beam/Grenade", 3);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addSoundEvent("AIM_START", ["fiskrework:cold_gun_aim", "fiskrework:cold_gun_static", "fiskrework:heat_gun_aim_fire", "fiskrework:heat_gun_aim_electric", "fiskrework:heat_gun_tank_fire", "fiskrework:heat_gun_tank_electric"]);
    //hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
}

function hasPermission(entity, permission) {
    return permission == "USE_COLD_GUN" || permission == "USE_HEAT_GUN" || permission == "USE_GUN";
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fiskheroes:cold_gun" || entity.getHeldItem().name() == "fiskheroes:heat_gun" || entity.getHeldItem().isGun();
}

function cryoTrigger(entity, manager) {
    var isCryoGrenade = entity.getHeldItem().nbt().getBoolean("Mode")
    if (!isCryoGrenade) {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", true)
        entity.playSound("fiskheroes:item.coldgun.aim", 1.0, 1.0)
    } else {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", false)
        entity.playSound("fiskheroes:item.coldgun.aim", 1.0, 1.0)
    }
    return true;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "CRYO":
        return entity.getHeldItem().name() == "fiskheroes:cold_gun" && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}