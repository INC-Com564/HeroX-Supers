function init(hero) {
    hero.setName("hero.fiskheroes.arrow.name");
    hero.setVersion("Rework");
    hero.setTier(4);

    hero.setHelmet("Mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:compound_bow");
    hero.addEquipment("fiskheroes:quiver");

    hero.addPowers("fiskrework:archery_rework", "fiskrework:throwing_darts");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    hero.addAttribute("BOW_DRAWBACK", 0.55, 1);

    hero.addKeyBind("QUIVER_CYCLE", "key.quiverCycle", 1);
    hero.addKeyBind("HORIZONTAL_BOW", "Horizontal Bow", 2);
    hero.addKeyBind("UTILITY_BELT", "Activate Throwing Darts", 3);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_CLOSE", "fiskrework:hood_up");
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addAttributeProfile("BOW", bowProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setTickHandler((entity, manager) => {
        if (entity.world().getBlock(entity.pos().add(0,1,0)) == "minecraft:water" || entity.world().isRaining() && entity.isWet() && (entity.rotPitch() < -45 && !entity.getData("fiskheroes:mask_open") || entity.rotPitch() < -20 && entity.getData("fiskheroes:mask_open"))) {
            manager.setData(entity, "fiskrework:dyn/arrow_wet", true)
            manager.setData(entity, "fiskrework:dyn/arrow_wet_cooldown", 0)
        }
        if (entity.world().getBlock(entity.pos().add(0,1,0)) == "minecraft:water" && entity.isSprinting()) {
            manager.setData(entity, "fiskheroes:flying", true)
        }
    });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    case "fiskheroes:controlled_flight":
        return entity.isInWater();
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "QUIVER_CYCLE":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    case "HORIZONTAL_BOW":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    default:
        return true;
    }
}

function getAttributeProfile(entity) {
    if ((entity.getHeldItem().name() === "fiskheroes:compound_bow" || entity.getHeldItem().name() === "minecraft:bow") && entity.as('PLAYER').isUsingItem()) {
        return "BOW";
    }
    return null
}

function bowProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 0.8, 1);
}
