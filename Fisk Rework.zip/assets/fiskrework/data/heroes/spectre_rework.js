function init(hero) {
    hero.setName("hero.fiskheroes.spectre.name");
    hero.setVersion("Rework")
    hero.setTier(10);

    hero.setHelmet("item.superhero_armor.piece.cloak");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:compound_bow");
    hero.addEquipment("fiskheroes:quiver");

    hero.addPowers("fiskrework:spirit_physiology_rework", "fiskrework:multiversal_protector");
    hero.addAttribute("PUNCH_DAMAGE", 13.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", -1.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);

    hero.addKeyBind("ENERGY_PROJECTION", "key.energyProjection", 1);
    hero.addKeyBind("QUIVER_CYCLE", "key.quiverCycle", 1);
    hero.addKeyBind("TELEPORT", "key.teleport", 2);
    hero.addKeyBind("HORIZONTAL_BOW", "key.horizontalBow", 2);
    hero.addKeyBind("SHIELD", "Forcefield", 3);
    hero.addKeyBind("ARROW_EMPOWER", "Arrow Multiversal Empower", 3);
    hero.addKeyBind("ARROW_TRANSFORM", "Green Arrow Transformation", 5);

    hero.setHasProperty(hasProperty);
    hero.setTierOverride(getTierOverride);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);
    hero.addAttributeProfile("SHIELD", shieldProfile);
    hero.addAttributeProfile("SPECTRE_BOW", bowSpectreProfile);
    hero.addAttributeProfile("ARROW", arrowProfile);
    hero.addAttributeProfile("ARROW_BOW", bowArrowProfile);
    hero.addAttributeProfile("ARROW_POWER", arrowPowerProfile);
    hero.setAttributeProfile(getAttributeProfile);
}


function getAttributeProfile(entity) {
    if ((entity.getHeldItem().name() === "fiskheroes:compound_bow" || entity.getHeldItem().name() === "minecraft:bow") && entity.as('PLAYER').isUsingItem()) {
        return entity.getData("fiskrework:dyn/arrow_empower") ? "ARROW_POWER" : entity.getData("fiskrework:dyn/arrow") ? "ARROW_BOW" : "SPECTRE_BOW";
    } else if (entity.getData("fiskheroes:shield")) {
        return "SHIELD";
    } else if (entity.getData("fiskrework:dyn/arrow")) {
        return "ARROW";
    }
    return null
}

function shieldProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.75, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function bowSpectreProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 0.65, 1);
}

function arrowProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    profile.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 5.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0.15, 1);
    profile.addAttribute("BOW_DRAWBACK", 0.55, 1);
}

function bowArrowProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    profile.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 5.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0.15, 1);
    profile.addAttribute("BOW_DRAWBACK", 0.55, 1);
    profile.addAttribute("BASE_SPEED", 0.95, 1);
}

function arrowPowerProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    profile.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 5.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0.15, 1);
    profile.addAttribute("BOW_DRAWBACK", 0.55, 1);
    profile.addAttribute("BASE_SPEED", 0.95, 1);
    profile.addAttribute("ARROW_DAMAGE", 1, 1);
}

function hasProperty(entity, property) {
    switch (property) {
        case "MASK_TOGGLE":
            return !entity.getData("fiskheroes:dyn/nanites");
        case "BREATHE_SPACE":
            return !entity.getData("fiskrework:dyn/arrow");
        default:
            return false;
    }
}

function getTierOverride(entity) {
    return entity.getData("fiskrework:dyn/arrow") || entity.getData("fiskrework:dyn/arrow_empower") ? 6 : 10;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:water_breathing":
            return !entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower");
        case "fiskheroes:leaping":
            return !entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower");
        case "fiskheroes:arrow_catching":
            return entity.isPunching();
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "HORIZONTAL_BOW":
        return entity.getData("fiskrework:dyn/arrow") &&  entity.getHeldItem().name() == "fiskheroes:compound_bow"|| entity.getData("fiskrework:dyn/arrow_empower") && entity.getHeldItem().name() == "fiskheroes:compound_bow";
    case "QUIVER_CYCLE":
        return entity.getData("fiskrework:dyn/arrow") &&  entity.getHeldItem().name() == "fiskheroes:compound_bow"|| entity.getData("fiskrework:dyn/arrow_empower") && entity.getHeldItem().name() == "fiskheroes:compound_bow";
    case "ARROW_EMPOWER":
        return entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower") && entity.getData("fiskrework:dyn/arrow_empower_cooldown") == 0;
    case "ARROW_TRANSFORM":
        return !entity.getData("fiskheroes:mask_open");
    case "ENERGY_PROJECTION":
        return !entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower") && entity.getHeldItem().isEmpty();
    case "TELEPORT":
        return !entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower");
    case "SHIELD":
        return !entity.getData("fiskrework:dyn/arrow") && !entity.getData("fiskrework:dyn/arrow_empower") && entity.getHeldItem().isEmpty();
    default:
        return true;
    }
}