function init(hero) {
    hero.setName("hero.fiskheroes.atom.name");
    hero.setVersion("Rework");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:atom_exosuit_rework");
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.05, 1);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 7.0, 0);

    hero.addKeyBind("AIM", "key.aim", 1);
    hero.addKeyBind("SIZE_MANIPULATION", "key.sizeManipulation", 2);
    hero.addKeyBindFunc("func_GIANT_MODE", giantModeKey, "key.giantMode", 3);
    hero.addKeyBind("MINIATURIZE_SUIT", "key.miniaturizeSuit", 5);

    hero.addAttributeProfile("SMALL", smallProfile);
    hero.addAttributeProfile("GIANT_MODE", giantProfile);
    hero.setAttributeProfile(getProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.setRuleValueModifier(ruleModifier);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setTierOverride(getTierOverride);
    hero.supplyFunction("canAim", canAim);

    hero.setTickHandler((entity, manager) => {
        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, entity.getData("fiskheroes:flying"));
        manager.incrementData(entity, "fiskheroes:dyn/shrink_timer", 3, entity.getData("fiskheroes:size_state") != 0);
        
    });
}

function ruleModifier(entity, rule) {
	if (rule.name() == "fiskheroes:ticks_qrtimer") {
		return rule.value() - 400
	}
    return null;
}

function getProfile(entity) {
    if (entity.getData("fiskheroes:scale") < 1 && entity.getData("fiskheroes:scale") >= 0.15625) {
        return "SMALL";
    } else if (entity.getData("fiskheroes:scale") > 1 && entity.getData("fiskheroes:scale") >= 5) {
        return "GIANT_MODE";
    }
    return null;
}

function giantProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 10.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.5, 0);
    profile.addAttribute("FALL_RESISTANCE", 12.0, 0);
    profile.addAttribute("BASE_SPEED", -0.4, 1);
    profile.addAttribute("SPRINT_SPEED", 0, 1);
}

function smallProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 9.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 0.0, 0);
    profile.addAttribute("BASE_SPEED", -0.6, 1);
}

function giantModeKey(player, manager) {
    var flag = player.getData("fiskheroes:dyn/giant_mode");
    manager.setData(player, "fiskheroes:dyn/giant_mode", !flag);
    manager.setData(player, "fiskheroes:size_state", flag ? -1 : 1);
    return true;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:controlled_flight":
            return !entity.getData("fiskheroes:dyn/giant_mode");
        case "fiskheroes:water_breathing":
            return entity.getData("fiskheroes:mask_open");
        case "fiskheroes:size_manipulation":
            return (modifier.id() == "giant") == (entity.getData("fiskheroes:dyn/giant_mode_timer") > 0 || entity.getData("fiskheroes:dyn/giant_mode"));
        default:
            return true;
    }
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/giant_mode") ? 7 : 6;
}

function isKeyBindEnabled(entity, keyBind) {
    if (entity.isSprinting() && entity.getData("fiskheroes:flying")) {
        return false;
    }
    return true;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "func_GIANT_MODE":
        return entity.getData("fiskheroes:size_state") == 0 && (entity.getData("fiskheroes:dyn/giant_mode") || entity.getData("fiskheroes:dyn/giant_mode_cooldown") == 0);
    case "SIZE_MANIPULATION":
        return !entity.getData("fiskheroes:dyn/giant_mode");
    case "MINIATURIZE_SUIT":
        return !entity.getData("fiskheroes:dyn/giant_mode") && entity.getData("fiskheroes:scale") == 1;
    case "AIM":
        return !entity.getData("fiskheroes:dyn/giant_mode") && entity.getData("fiskheroes:scale") == 1;
    default:
        return true;
    }
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE" || property == "BREATHE_SPACE" && entity.getData("fiskheroes:mask_open");
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}