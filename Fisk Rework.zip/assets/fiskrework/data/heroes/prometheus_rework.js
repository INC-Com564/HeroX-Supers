function init(hero) {
    hero.setName("hero.fiskheroes.prometheus.name");
    hero.setVersion("Rework")
    hero.setTier(5);

    hero.setHelmet("Mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:chokuto", true, item => !item.nbt().getBoolean("Dual"));
    hero.addEquipment("fiskheroes:compound_bow");
    hero.addEquipment("fiskheroes:quiver");

    hero.addPowers("fiskrework:archery_rework", "fiskheroes:throwing_stars");
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 5.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 5.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);
    hero.addAttribute("BOW_DRAWBACK", 0.55, 1);

    hero.addKeyBind("QUIVER_CYCLE", "key.quiverCycle", 1);
    hero.addKeyBind("HORIZONTAL_BOW", "key.horizontalBow", 2);
    hero.addKeyBind("UTILITY_BELT", "key.throwingStars", 3);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_CLOSE", "fiskrework:hood_up");
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addAttributeProfile("BOW", bowProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setAttributeProfile(getAttributeProfile);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "QUIVER_CYCLE":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    case "HORIZONTAL_BOW":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    default:
        return true;
    }
}

function getAttributeProfile(entity) {
    return (entity.getHeldItem().name() === "fiskheroes:compound_bow" || entity.getHeldItem().name() === "minecraft:bow") && entity.as('PLAYER').isUsingItem() ? "BOW" : null;
}

function bowProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 0.85, 1);
}