function init(hero) {
    hero.setName("hero.fiskheroes.obsidian.name");
    hero.setVersion("Rework");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.hood");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:umbrakinesis_rework");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);

    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);
    hero.addKeyBind("SHADOWFORM", "key.shadowForm", 1);
    hero.addKeyBind("AIM", "key.shadowChain", 2);
    hero.addKeyBind("TELEKINESIS", "key.shadowChain", 2);
    hero.addKeyBind("SHADOWDOME", "key.shadowDome", 3);
    hero.addKeyBind("SHADOW", "Toggle Partial Shadow Form", 4);
    hero.addKeyBind("TELEPORT", "Shadow Warp", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:flight":
        switch (modifier.id()) {
        case "shadowformFlight":
            return (entity.getData("fiskheroes:shadowform"));
        case "partialShadowformFlight":
            return (entity.getData("fiskrework:dyn/partial_shadowform"));
        };
    case "fiskheroes:telekinesis":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskrework:dyn/partial_shadowform");
    case "fiskheroes:projectile_immunity":
        return entity.getData("fiskrework:dyn/partial_shadowform_timer") == 1;
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "DISABLE_PUNCH":
        return entity.getData("fiskheroes:grab_id") > -1 || entity.getData("fiskrework:dyn/partial_shadowform");
    case "SHADOWFORM":
        return !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskrework:dyn/partial_shadowform");
    case "TELEKINESIS":
        return !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskrework:dyn/partial_shadowform");
    case "AIM":
        return !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskrework:dyn/partial_shadowform");
    case "SHADOWDOME":
        return !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskrework:dyn/partial_shadowform");
    case "SHADOW":
        return !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskheroes:telekinesis");
    case "TELEPORT":
        return !entity.getData("fiskheroes:shadowform") && !entity.getData("fiskheroes:lightsout") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskrework:dyn/partial_shadowform");
    default:
        return true;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:grab_id") > -1;
}
