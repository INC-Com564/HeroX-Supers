function init(hero) {
    hero.setName("hero.fiskheroes.captain_america.name");
    hero.setVersion("Rework")
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:captain_americas_shield", true);

    hero.addPowers("fiskrework:super_soldier_serum_rework", "fiskheroes:shield_throwing");
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);
    hero.addAttribute("STEP_HEIGHT", 0.5, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("SHIELD_THROW", "key.shieldThrow", 1);

    hero.setHasPermission((entity, permission) => permission == "USE_SHIELD" || permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addAttributeProfile("SHIELD", shieldProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setTickHandler((entity, manager) => {
        if (entity.rotPitch() > 69 && entity.motionY() < -0.8 && entity.getHeldItem().name() === "fiskheroes:captain_americas_shield" && entity.as('PLAYER').isBlocking()) {
            manager.setData(entity, "fiskheroes:dyn/nanites", true);
        }
        if (entity.rotPitch() <= 69 || entity.motionY() >= -0.8 || !entity.getHeldItem().name() === "fiskheroes:captain_americas_shield") {
            manager.setData(entity, "fiskheroes:dyn/nanites", false);
        }
    });
}


function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "SHIELD_THROW":
        return entity.getHeldItem().name() == "fiskheroes:captain_americas_shield";
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    default:
        return true;
    }
}

function getAttributeProfile(entity) {
    return (entity.getHeldItem().name() === "fiskheroes:captain_americas_shield" && entity.as('PLAYER').isUsingItem()) ? "SHIELD" : null;
}

function shieldProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 0.8, 1);
}