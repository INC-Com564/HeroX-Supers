var landing = implement("fiskrework:external/superhero_fall_landing");

function init(hero) {
    hero.setName("Deadpool/X-Men");
    hero.setVersion("Rework");
    hero.setAliases("dp");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:katana{Dual:1}", true, item => item.nbt().getBoolean("Dual"));
    hero.addPrimaryEquipment("fiskheroes:desert_eagle{Dual:1}", true, item => item.nbt().getBoolean("Dual"));

    hero.addPowers("fiskrework:healing_factor_rework");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 5.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.setRuleValueModifier(ruleModifier);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");

    hero.setTickHandler((entity, manager) => {
        landing.tick(entity, manager);
     });
}

function ruleModifier(entity, rule) {
    switch (rule.name()) {
    case "fiskheroes:cooldown_deserteagle":
        return rule.value() - 2;
    case "fiskheroes:dmgmult_deserteagle":
        return rule.value() - 0.2;
    case "fiskheroes:spread_deserteagle":
        return rule.value() + 0.2;
    case "fiskheroes:recoil_deserteagle":
        return rule.value() + 0.3;
    default:
        return null;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}
