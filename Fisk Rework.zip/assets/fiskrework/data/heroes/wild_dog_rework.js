function init(hero) {
    hero.setName("hero.fiskheroes.wild_dog.name");
    hero.setVersion("Rework");
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:beretta_93r{Dual:1}", true, item => item.nbt().getBoolean("Dual"));

    hero.addPowers("fiskheroes:bullet_resistance", "fiskrework:flashbangs");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "Toggle Flashbangs", 2);
    hero.addKeyBindFunc("BURST", cycleMode, "Trigger 3-Shot Burst/Single Shot", 3);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
}

function cycleMode(entity, manager) {
    var isBurst = entity.getHeldItem().nbt().getBoolean("Mode")
    if (!isBurst) {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", true)
        entity.playSound("fiskheroes:item.gun.beretta.switch", 1.0, 1.0)
    } else {
        manager.setBoolean(entity.getHeldItem().nbt(), "Mode", false)
        entity.playSound("fiskheroes:item.gun.beretta.switch", 1.0, 1.0)
    }
    return true;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "BURST":
        return entity.getHeldItem().name() == "fiskheroes:beretta_93r" && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}