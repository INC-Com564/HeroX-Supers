function init(hero) {
    hero.setName("hero.fiskheroes.chronos.name");
    hero.setVersion("Rework")
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:chronos_rifle", true);
    hero.addPrimaryEquipment("fiskheroes:heat_gun", false);

    hero.addPowers("fiskrework:chronos_armor");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "key.grenades", 2);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);
    hero.setRuleValueModifier(ruleModifier);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addSoundEvent("AIM_START", ["fiskrework:heat_gun_aim_fire", "fiskrework:heat_gun_aim_electric", "fiskrework:heat_gun_tank_fire", "fiskrework:heat_gun_tank_electric", "fiskrework:cold_gun_aim", "fiskrework:cold_gun_static"]);
}

function hasPermission(entity, permission) {
    return permission == "USE_CHRONOS_RIFLE" || permission == "USE_HEAT_GUN" || permission == "USE_COLD_GUN" || permission == "USE_GUN";
}

function ruleModifier(entity, rule) {
    if (rule.name() == "fiskheroes:dmgmult_laserbolt") {
		return rule.value() + 0.5
	}
    return null;
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fiskheroes:chronos_rifle" || entity.getHeldItem().name() == "fiskheroes:heat_gun" || entity.getHeldItem().name() == "fiskheroes:cold_gun" || entity.getHeldItem().isGun();
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    default:
        return true;
    }
}