var speedster_base = implement("fiskheroes:external/speedster_base");

function init(hero) {
    hero.setName("hero.fiskheroes.the_flash_hunter.name");
    hero.setVersion("Rework")
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:flash_ring");

    hero.addPowers("fiskrework:speed_force_rework");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("BASE_SPEED_LEVELS", 3.0, 0);

    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);
    hero.addKeyBind("CHARGED_BEAM", "Wind Funnel", 3);
    hero.addKeyBind("INTANGIBILITY", "Phase", 5);

    var speedPunch = speedster_base.createSpeedPunch(hero);
    hero.setDamageProfile(entity => speedPunch.get(entity, null));

    hero.addSoundOverrides("JAY", speedster_base.mergeSounds("fiskrework:speed_force_rework", speedster_base.SOUNDS_JAY));

    hero.addAttributeProfile("INVIS", invisProfile);
    hero.addAttributeProfile("CLEAR", clearProfile);
    hero.addAttributeProfile("WIND", windFunnelProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setTickHandler((entity, manager) => {
        speedster_base.tick(entity, manager);
    });
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskrework:dyn/effect_clear")) {
      return "CLEAR";
    }
    else if (entity.getData("fiskheroes:beam_shooting_timer") > 0) {
        return "WIND";
    }
    return entity.getData("fiskheroes:invisible") ? "INVIS": null;
}

function clearProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function invisProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function windFunnelProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:invisibility":
        return entity.getData("fiskrework:dyn/speed_force_invis");
    case "fiskheroes:damage_immunity":
        return modifier.id() == "catch3" == (entity.isPunching() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4);
    case "fiskheroes:potion_immunity":
        return modifier.id() == "vibrate3" == (entity.getData("fiskrework:dyn/effect_clear"));
    case "fiskheroes:lightning_cast":
        return entity.isSprinting() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && !entity.getData("fiskheroes:beam_shooting");
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    case "fiskheroes:charged_beam":
        switch (modifier.id()) {
        case "wind_funnel":
            return (!entity.getData("fiskheroes:aiming"));
        case "speed_steal":
            return (entity.getData("fiskheroes:aiming"));
        };
    case "fiskheroes:flight":
        return entity.isInWater() && !entity.isSneaking() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && (entity.world().blockAt(entity.pos().subtract(0,0.05,0)).isSolid());
    case "fiskheroes:fire_immunity":
        return entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:intangible");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "EFFECT_CLEAR":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 3 && entity.isOnGround() && !entity.getData("fiskrework:dyn/effect_clear_cooldown") >=1;
    case "INTANGIBILITY":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 5 && !entity.isOnGround() && !entity.getData("fiskheroes:dyn/intangibility_cooldown") >=1;
    case "CHARGED_BEAM":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && entity.isOnGround();
    case "INVISIBILITY":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 7 && entity.isOnGround() && !entity.getData("fiskrework:dyn/speed_force_invis_cooldown") >=1;
    default:
        return true;
    }
}
