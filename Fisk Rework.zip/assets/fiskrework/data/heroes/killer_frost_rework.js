function init(hero) {
    hero.setName("hero.fiskheroes.killer_frost.name");
    hero.setAliases("frost", "kfrost");
    hero.setVersion("Rework")
    hero.setTier(3);

    hero.setHelmet("item.superhero_armor.piece.hair");
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:cryogenic_physiology_rework");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);

    hero.addKeyBind("CHARGE_ICE", "key.chargeIce", 1);
    hero.addKeyBind("BLADE", "key.iceSpike", 2);
    hero.addKeyBind("CHARGED_BEAM", "Frost Blast", 3);
    hero.addKeyBind("CRYOBALL", "Toggle Cryoball", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setDamageProfile(getDamageProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "COLD": 0.4
        }
    });
    hero.addDamageProfile("ICE_PUNCH", {
        "types": {
            "BLUNT": 1.0,
            "COLD": 0.2
        }
    });

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskheroes:beam_shooting_timer") > 0) {
            manager.setData(entity, "fiskheroes:cryo_charge", entity.getData("fiskheroes:cryo_charge") - 0.025);
        }
    });
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
}

function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:blade") ? "BLADE" : null;
}

function getDamageProfile(entity) {
    return entity.getData("fiskheroes:blade") ? "BLADE" : entity.getData("fiskheroes:cryo_charge") > 0 ? "ICE_PUNCH" : null;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:cryoball":
            return entity.getData("fiskrework:dyn/cryo");
        case "fiskheroes:icicles":
            return !entity.getData("fiskrework:dyn/cryo") && !entity.getData("fiskheroes:beam_shooting_timer") > 0;
        case "fiskheroes:frost_walking":
            switch (modifier.id()) {
            case "low":
                return entity.getData("fiskheroes:cryo_charge") >= 0 && entity.getData("fiskheroes:cryo_charge") <= 0.25;
            case "medium":
                return entity.getData("fiskheroes:cryo_charge") > 0.25 && entity.getData("fiskheroes:cryo_charge") <= 0.5;
            case "large":
                return entity.getData("fiskheroes:cryo_charge") > 0.5 && entity.getData("fiskheroes:cryo_charge") <= 0.75;
            case "full":
                return entity.getData("fiskheroes:cryo_charge") > 0.75 && entity.getData("fiskheroes:cryo_charge") <= 1;
            };
        case "fiskheroes:blade":
            return entity.getData("fiskheroes:cryo_charge") > 0;
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "CHARGE_ICE":
        return !entity.getData("fiskheroes:blade") && !entity.getData("fiskrework:dyn/cryo") && !entity.getData("fiskheroes:beam_shooting_timer") > 0;
    case "BLADE":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:cryo_charge") == 1 || entity.getData("fiskheroes:blade") || entity.isBookPlayer();
    case "CHARGED_BEAM":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:cryo_charge") == 1 && !entity.getData("fiskheroes:blade") || entity.getData("fiskheroes:beam_shooting_timer") > 0;
    case "CRYOBALL":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:cryo_charge") == 0 || entity.getData("fiskrework:dyn/cryo");
    default:
        return true;
    }
}
