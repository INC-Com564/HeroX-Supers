var landing = implement("fiskrework:external/superhero_swing_landing");

function init(hero) {
    hero.setName("Spider-Man/PS4");
    hero.setVersion("Rework");
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:spider_physiology_rework", "fiskrework:web_shooters_ps4_rework");
    hero.addAttribute("FALL_RESISTANCE", 13.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.0, 0);
    hero.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.45, 1);
    hero.addAttribute("STEP_HEIGHT", 0.5, 0);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("UTILITY_BELT", "key.webShooters", 1);
    hero.addKeyBind("WEBS", "Cycle Web Types", 1);
    hero.addKeyBind("WEB_ZIP", "key.webZip", 2);
    hero.addKeyBindFunc("func_WEB_SWINGING", webSwingingKey, "key.webSwinging", 3);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotionHold", 4);
    hero.addKeyBindFunc("func_SWING_KICK", glideKey, "Swing Kick", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setDamageProfile(getAttributeProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.addAttributeProfile("KICK", kickProfile);
    hero.addAttributeProfile("LAND", landProfile);
    hero.setTickHandler((entity, manager) => {
        if (!entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 7, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));;
        }
        else if (entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 30, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));
        }
        manager.incrementData(entity, "fiskrework:dyn/perch_timer", 6, entity.getData("fiskrework:dyn/sneaking_timer") == 1);

        landing.tick(entity, manager);

        if (entity.getData("fiskrework:dyn/swing_kick")) {
            manager.setData(entity, "fiskheroes:gliding", true);
        }
     });
}

function webSwingingKey(player, manager) {
    var flag = player.getData("fiskheroes:web_swinging");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
    }

    manager.setDataWithNotify(player, "fiskheroes:web_swinging", !flag);
    return true;
}

function glideKey(player, manager, entity) {
    var swing = (player.getData("fiskheroes:web_swinging_timer") < 1);

    if (swing) {
        return false;
    }

    var flag = player.getData("fiskheroes:gliding");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
    }

    manager.setDataWithNotify(player, "fiskheroes:gliding", !flag);
    return true;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:web_swinging":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:utility_belt_type") == -1;
    case "fiskheroes:leaping":
        return modifier.id() == "springboard" == (entity.getData("fiskheroes:ticks_since_swinging") < 5);
    case "fiskheroes:arrow_catching":
        return entity.isPunching() || entity.getData("fiskheroes:slow_motion");
    case "fiskheroes:gliding":
        return (entity.getData("fiskrework:dyn/swing_kick") && entity.getData("fiskheroes:web_swinging_timer") == 1);
    case "fiskheroes:equipment":
        switch (modifier.id()) {
        case "basic":
            return (!entity.getData("fiskrework:dyn/special_webs"));
        case "special":
            return (entity.getData("fiskrework:dyn/special_webs"));
        };
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "func_WEB_SWINGING":
        return entity.getHeldItem().isEmpty();
    case "UTILITY_BELT":
        return !entity.isSneaking() || entity.getData("fiskrework:dyn/sneaking_timer") == 1;
    case "WEBS":
        return entity.isSneaking() && entity.getData("fiskrework:dyn/sneaking_timer") < 1;
    case "func_SWING_KICK":
        return entity.getData("fiskheroes:web_swinging_timer") == 1;
    default:
        return true;
    }
}

function landProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 26.0, 0);
}

function kickProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("IMPACT_DAMAGE", 2.0, 1);
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskheroes:dyn/superhero_landing_timer") > 0) {
        return "LAND";
    }
    else if (entity.getData("fiskrework:dyn/swing_kick")) {
        return "KICK"
    }
}