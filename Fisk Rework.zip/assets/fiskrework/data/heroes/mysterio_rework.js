var super_boost = implement("fiskheroes:external/super_boost");

function init(hero) {
    hero.setName("Mysterio");
    hero.setVersion("Rework");
    hero.setTier(3);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:drone_illusions_rework");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);

    hero.addKeyBind("CHARGED_BEAM", "key.chargedBeam", 1);
    hero.addKeyBind("AIM", "key.energyProjection", 2);
    hero.addKeyBind("ENERGY_PROJECTION", "key.energyProjection", 2);
    hero.addKeyBind("ENERGY_TRANSFORM", "Toggle Energy Projection/Energy Blast", 2);
    hero.addKeyBind("SPELL_MENU", "key.illusionMenu", 3);
    hero.addKeyBind("SHIELD", "Illusion Shield", 3);
    hero.addKeyBind("SHADOWDOME", "Blackout", 4);
    hero.addKeyBind("TELEPORT", "Warp Illusion", 5);
    hero.addKeyBind("INVIS", "Cloak", 5);
    super_boost.addKeyBind(hero, "key.boost", 1);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.supplyFunction("canAim", canAim);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:mysterio_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:mysterio_mask_close");
    hero.addSoundEvent("AIM_START", "fiskheroes:mysterio_beam_aim");

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskrework:dyn/invis_timer") == 1) {
            manager.setData(entity, "fiskheroes:invisible", true);
        }
        super_boost.tick(entity, manager);
    });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:energy_projection":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskrework:dyn/beam_toggle");
    case "fiskheroes:charged_beam":
        return entity.getHeldItem().isEmpty();
    case "fiskheroes:repulsor_blast":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskrework:dyn/beam_toggle");
    case "fiskheroes:invisibility":
        return entity.getData("fiskrework:dyn/invis");
    default:
        return super_boost.isModifierEnabled(entity, modifier);
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "ENERGY_PROJECTION":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:beam_charge") == 0 && entity.getData("fiskheroes:aimed_timer") >= 1 && !entity.getData("fiskrework:dyn/beam_toggle");
    case "AIM":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskrework:dyn/invis") && !entity.isSneaking();
    case "CHARGED_BEAM":
        return !(entity.isSprinting() && entity.getData("fiskheroes:flying")) && entity.getHeldItem().isEmpty() && !entity.getData("fiskrework:dyn/invis");
    case "TELEPORT":
        return !entity.getData("fiskheroes:beam_shooting") && !entity.isSneaking();
    case "SPELL_MENU":
        return !entity.isSneaking();
    case "SHIELD":
        return entity.isSneaking();
    case "SHADOWDOME":
        return !(entity.getData("fiskheroes:beam_shooting") && entity.getHeldItem().isEmpty());
    case "INVIS":
        return !entity.getData("fiskheroes:beam_shooting") && entity.isSneaking();
    case "ENERGY_TRANSFORM":
        return !entity.getData("fiskheroes:beam_shooting") && entity.isSneaking();
    default:
        return super_boost.isKeyBindEnabled(entity, keyBind);
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:beam_charge") == 0 && entity.getData('fiskheroes:time_since_damaged') > 10;
}
