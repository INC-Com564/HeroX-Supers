var wraith_base = implement("fiskrework:external/wraith_base");
var super_boost = implement("fiskheroes:external/super_boost");

function init(hero)
{
    hero.setName("Time Wraith");
    hero.setTier(4);
    hero.hide();

    hero.setHelmet("Head");
    hero.setChestplate("Chest");
    hero.setLeggings("Scraps");

    hero.addPowers("fiskrework:time_wraith_physiology");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);

    super_boost.addKeyBind(hero, "key.boost", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);

    hero.addSoundEvent("EQUIP", ["fiskrework:time_wraith_flight_loop"]);
    hero.addDamageProfile("FIST", {"types": {"SHARP": 1.0}, "properties":{"EFFECTS": [
        {
          "id": "minecraft:wither",
          "duration": 80,
          "amplifier": 2,
          "chance": 0.5
        },
        {
          "id": "fiskheroes:disable_speed",
          "duration": 40,
          "amplifier": 0,
          "chance": 0.1
        }
    ]}});

    hero.addSoundOverrides("BARRY", wraith_base.mergeSounds("fiskrework:time_wraith_physiology", wraith_base.SOUNDS_BARRY));
    hero.addSoundOverrides("ZOOM", wraith_base.mergeSounds("fiskrework:time_wraith_physiology", wraith_base.SOUNDS_ZOOM));
    hero.addSoundOverrides("NEGATIVE", wraith_base.mergeSounds("fiskrework:time_wraith_physiology", wraith_base.SOUNDS_NEGATIVE));
    hero.addSoundOverrides("KF", wraith_base.mergeSounds("fiskrework:time_wraith_physiology", wraith_base.SOUNDS_KF));
    hero.addSoundOverrides("COMICS", wraith_base.mergeSounds("fiskrework:time_wraith_physiology", wraith_base.SOUNDS_COMICS));

    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addSoundEvent("MASK_OPEN", "fiskrework:time_wraith_roar");
    hero.addSoundEvent("MASK_CLOSE", "fiskrework:time_wraith_roar");
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setAttributeProfile(getProfile);
    hero.setTickHandler((entity, manager) => {
    manager.setData(entity, "fiskheroes:flying", true);
	  manager.setData(entity, "fiskheroes:intangible", true);
    
    super_boost.tick(entity, manager);
    });
  }

  function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:arrow_catching":
            return entity.isPunching();
    default:
        return super_boost.isModifierEnabled(entity, modifier);
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    default:
        return super_boost.isKeyBindEnabled(entity, keyBind);
    }
}

    function getProfile(entity) {
      return entity.isWearingFullSuit() && (entity.getWornChestplate().suitType() == 'fiskrework:time_wraith') ? "FIST" : null
  }