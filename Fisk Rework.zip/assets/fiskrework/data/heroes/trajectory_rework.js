var speedster_base = implement("fiskheroes:external/speedster_base");

function init(hero) {
    hero.setName("hero.fiskheroes.trajectory.name");
    hero.setVersion("Rework")
    hero.setTier(3);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:flash_ring");

    hero.addPowers("fiskrework:velocity_nine_rework");
    hero.addAttribute("PUNCH_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);
    hero.addAttribute("BASE_SPEED_LEVELS", 6.0, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun() && entity.getData("fiskheroes:speed") > 4);
    hero.setTickHandler((entity, manager) => {
        speedster_base.tick(entity, manager);
    });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:damage_immunity":
        return modifier.id() == "catch3" == (entity.isPunching() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4);
    case "fiskheroes:lightning_cast":
        return entity.isSprinting() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") == 4;
    case "fiskheroes:speed_disintegration":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") > 4 && !entity.hasStatusEffect("fiskheroes:velocity_nine") || entity.hasStatusEffect("fiskheroes:speed_sickness");
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    case "fiskheroes:flight":
        return entity.isInWater() && !entity.isSneaking() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && (entity.world().blockAt(entity.pos().subtract(0,0.05,0)).isSolid());
    case "fiskheroes:fire_immunity":
        return entity.getData("fiskrework:dyn/effect_clear") || entity.getData("fiskheroes:intangible");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming") && entity.getData("fiskheroes:speed") >= 4;
    case "SUPER_SPEED":
        return !entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}