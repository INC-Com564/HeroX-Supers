var landing = implement("fiskrework:external/superhero_cape_landing");

function init(hero) {
    hero.setName("Batman/DCEU");
    hero.setVersion("Rework");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.cowl");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);

    hero.addPowers("fiskrework:batsuit_rework");
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "key.utilityBelt", 1);

    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);
    hero.addAttributeProfile("LAND", landProfile);
    hero.setAttributeProfile(getProfile);
    hero.setHasPermission((entity, permission) => permission == "USE_GRAPPLING_GUN" || permission == "USE_GUN");

    hero.setTickHandler((entity, manager) => {
    if (entity.getData("fiskheroes:gliding")) {
        manager.setData(entity, "fiskheroes:flight_boost_timer", 1);
    }
    if (entity.getData("fiskheroes:gliding") && entity.rotPitch() < 45) {
        manager.setData(entity, "fiskrework:dyn/dive_timer", 1);
    }
    landing.tick(entity, manager);
 });
}

function getProfile(entity) {
    return entity.getData("fiskheroes:dyn/superhero_landing_timer") ? "LAND" : null
}

function landProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 1.0, 1);
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "UTILITY_BELT":
        return !entity.getHeldItem().isGun();
    default:
        return true;
    }
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        return entity.getData("fiskheroes:gliding");
    default:
        return true;
    
    }
}