function init(hero) {
    hero.setName("hero.fiskheroes.rip_hunter.name");
    hero.setVersion("Rework")
    hero.setAliases("rip");
    hero.setTier(1);

    hero.setChestplate("item.superhero_armor.piece.trenchcoat");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:rip_hunters_gun", true);
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:fiskrework:knife}", true, item => item.nbt().getString("WeaponType") == 'fiskrework:knife');

    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);

    hero.addKeyBind("AIM", "key.aim", -1);

    hero.setHasPermission(hasPermission);
    hero.setRuleValueModifier(ruleModifier);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}

function ruleModifier(entity, rule) {
    switch (rule.name()) {
    case "fiskheroes:dmgmult_laserbolt":
        return rule.value() + 0.5;
    case "fiskheroes:cooldown_ripsgun":
        return rule.value() + 4;
    default:
        return null;
    }
}

function hasPermission(entity, permission) {
    return permission == "USE_RIPS_GUN" || permission == "USE_GUNS";
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fiskheroes:rip_hunters_gun" || entity.getHeldItem().isGun();
}
