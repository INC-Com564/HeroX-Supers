function init(hero) {
    hero.setName("hero.fiskheroes.firestorm.name");
    hero.setVersion("Rework")
    hero.setTier(4);

    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.shoes");

    hero.addPowers("fiskrework:firestorm_matrix_rework");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 5.0, 0);

    hero.addKeyBind("HEAT_VISION", "key.shoot", 1);
    hero.addKeyBind("AIM", "key.shoot", 1);
    hero.addKeyBind("BLADE", "Ignite/Extinguish Hands", 3)

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.supplyFunction("canAim", canAim);

    hero.setDamageProfile(entity => !entity.getData("fiskheroes:blade") && entity.getHeldItem().isEmpty() ? "FLAME_PUNCH" : null);
    hero.addDamageProfile("FLAME_PUNCH", {
        "types": {
            "BLUNT": 1.0,
            "FIRE": 0.4
        },
        "properties": {
            "HEAT_TRANSFER": 40,
            "IGNITE": 2
        }
    });

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:flame_off");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:flame_on");
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "AIM":
            return !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:blade");
        case "HEAT_VISION":
            return !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:blade");
        default:
            return true;
    }
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:fireball":
            return !(entity.isSprinting() && entity.getData("fiskheroes:flying")) && !entity.getData("fiskheroes:blade");
        case "fiskheroes:flame_blast":
            return !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:blade");
        case "fiskheroes:heat_vision":
            return !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:blade");
        case "fiskheroes:controlled_flight":
            return !entity.getData("fiskheroes:blade");
        default:
            return true;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:blade");
}