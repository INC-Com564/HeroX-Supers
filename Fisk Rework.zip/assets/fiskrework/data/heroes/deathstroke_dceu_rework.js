function init(hero) {
    hero.setName("Deathstroke/DCEU");
    hero.setVersion("Rework");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:katana{Dual:1}", true, item => item.nbt().getBoolean("Dual"));
    hero.addPrimaryEquipment("fiskheroes:desert_eagle", true, item => !item.nbt().getBoolean("Dual"));

    hero.addPowers("fiskheroes:bullet_immunity", "fiskrework:enhanced_physiology_rework", "fiskheroes:grenades");
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 5.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "key.grenades", 2);

    hero.setRuleValueModifier(ruleModifier);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
}

function ruleModifier(entity, rule) {
    if (!entity.isSneaking() && rule.name() == "fiskheroes:spread_deserteagle") {
		return rule.value() - 0.4
	}
    if (rule.name() == "fiskheroes:ticks_reload_desert_eagle") {
		return rule.value() - 0.4
	}
    if (rule.name() == "fiskheroes:spread_beretta93r") {
		return rule.value() - 0.4
	}
    if (entity.isSneaking() && rule.name() == "fiskheroes:spread_deserteagle") {
		return rule.value() - 0.7
	}
    if (entity.isSneaking() && rule.name() == "fiskheroes:cooldown_deserteagle") {
		return rule.value() + 12
	}
    return null;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "UTILITY_BELT":
        return !entity.getHeldItem().isGun();
    default:
        return true;
    }
}
