var landing = implement("fiskheroes:external/superhero_landing");

function init(hero) {
    hero.setName("hero.fiskheroes.iron_man.name");
    hero.setVersion("Rework")
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:iron_man_armor_rework");
    hero.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 12.0, 0);

    hero.addKeyBind("HEAT_VISION", "Repulsor Beam", -1);
    hero.addKeyBind("AIM", "key.aim", 1);
    hero.addKeyBind("ENERGY_PROJECTION", "Laser", 2);
    hero.addKeyBind("UTILITY_BELT", "Activate Missles", 3);
    hero.addKeyBind("CHARGED_BEAM", "Unibeam", 4);
    hero.addKeyBind("SENTRY_MODE", "key.sentryMode", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");
    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "fiskheroes:iron_man_walk");
    hero.addSoundOverrides("MK46", {
        "suit": {
            "MASK_OPEN": "fiskheroes:iron_man_mk46_mask_open",
            "MASK_CLOSE": "fiskheroes:iron_man_mk46_mask_close"
        }
    });

    hero.setTickHandler((entity, manager) => {
        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        landing.tick(entity, manager);
    });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:water_breathing":
            return !entity.getData("fiskheroes:mask_open");
        case "fiskheroes:repulsor_blast":
            return !entity.getData("fiskheroes:heat_vision");
        default:
            return true;
        }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "AIM":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:energy_projection") && entity.getData("fiskheroes:utility_belt_type") == -1;
    case "ENERGY_PROJECTION":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:utility_belt_type") == -1 && !(entity.isSprinting() && entity.getData("fiskheroes:flying")) && !entity.getData("fiskheroes:aiming");
    case "CHARGED_BEAM": 
        return !entity.getData("fiskheroes:aiming") && entity.getData("fiskheroes:utility_belt_type") == -1 && !entity.getData("fiskheroes:energy_projection") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    case "UTILITY_BELT":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:aiming");
    case "HEAT_VISION":
        return entity.getData("fiskheroes:aiming") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
    default:
        return true;
    }
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE" || property == "BREATHE_SPACE" && !entity.getData("fiskheroes:mask_open");
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}
