function init(hero) {
    hero.setName("hero.fiskheroes.heatwave.name");
    hero.setVersion("Rework")
    hero.setTier(2);

    hero.setHelmet("item.superhero_armor.piece.goggles");
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:heat_gun", true);

    hero.addPowers("fiskheroes:heat_resistance");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 2.5, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addSoundEvent("AIM_START", ["fiskrework:heat_gun_firing", "fiskrework:heat_gun_aim_fire", "fiskrework:heat_gun_aim_electric", "fiskrework:heat_gun_tank_fire", "fiskrework:heat_gun_tank_electric", "fiskrework:cold_gun_aim", "fiskrework:cold_gun_static"]);
}

function hasPermission(entity, permission) {
    return permission == "USE_HEAT_GUN" || permission == "USE_COLD_GUN" || permission == "USE_GUN";
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fiskheroes:heat_gun" || entity.getHeldItem().name() == "fiskheroes:cold_gun" || entity.getHeldItem().isGun();
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}