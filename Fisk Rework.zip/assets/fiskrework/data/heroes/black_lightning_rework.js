function init(hero) {
    hero.setName("hero.fiskheroes.black_lightning.name");
    hero.setVersion("Rework");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:electrokinesis_rework", "fiskrework:black_lightning_suit");
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);

    hero.addKeyBind("CHARGED_BEAM", "Electric Discharge", 1);
    hero.addKeyBind("SHIELD", "Electric Shield", 2);
    hero.addKeyBind("TELEKINESIS", "Lightning Grab", 3);
    hero.addKeyBind("AIM", "Lightning Grab", 3);
    hero.addKeyBind("GOGGLES", "Activate Goggles", 4);
    hero.addKeyBind("INVIS", "Suit Camoflauge", 5);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addAttributeProfile("SHIELD", shieldProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.supplyFunction("canAim", canAim);

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskrework:dyn/invis_timer") == 1) {
            manager.setData(entity, "fiskheroes:invisible", true);
        }
});
}

function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:shield_blocking") ? "SHIELD" : null;
}

function shieldProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.9, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:controlled_flight":
            return !entity.getData("fiskheroes:invisible");
        case "fiskheroes:lightning_cast":
            return !entity.getData("fiskheroes:invisible");
        case "fiskheroes:invisibility":
            return entity.getData("fiskrework:dyn/invis");
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "CHARGED_BEAM":
            return !entity.getData("fiskheroes:invisible") && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:shield");
        case "SHIELD":
            return !entity.getData("fiskheroes:invisible") && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:telekinesis") && !entity.getData("fiskheroes:beam_charging");
        case "TELEKINESIS":
            return !entity.getData("fiskheroes:invisible") && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:beam_charging");
        case "AIM":
            return !entity.getData("fiskheroes:invisible") && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:beam_charging");;
        case "INVIS":
            return !entity.getData("fiskheroes:flying");
        default:
            return true;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:grab_id") > -1;
}
