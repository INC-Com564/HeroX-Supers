function init(hero) {
    hero.setName("hero.fiskheroes.ant_man.name");
    hero.setVersion("Rework");
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:pym_particles_rework");
    hero.addAttribute("PUNCH_DAMAGE", 4.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);

    hero.addKeyBind("SIZE_MANIPULATION", "key.sizeManipulation", 1);
    hero.addKeyBind("MINI", "Minimum Size", 1);
    hero.addKeyBind("SMALL", "Smaller Size", 2);
    hero.addKeyBind("LARGE", "Larger Size", 3);
    hero.addKeyBind("GIANT", "Giant Size", 4);
    hero.addKeyBind("SHORT", "Shorter Size", 1);
    hero.addKeyBind("TALL", "Taller Size", 2);
    hero.addKeyBind("QUANTUM", "Quantum Size", 4);
    hero.addKeyBind("SIZE_SLIDE", "Modify Size Manipulation", 5)

    hero.addAttributeProfile("MINI", miniProfile)
    hero.addAttributeProfile("SMALL", smallProfile);
    hero.addAttributeProfile("SHORT", shortProfile);
    hero.addAttributeProfile("TALL", tallProfile);
    hero.addAttributeProfile("LARGE", largeProfile);
    hero.addAttributeProfile("GIANT", giantProfile);
    hero.setAttributeProfile(getProfile);
    hero.setRuleValueModifier(ruleModifier);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.setTierOverride(getTierOverride);

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskheroes:scale") > 1) {
            manager.setData(entity, "fiskheroes:dyn/giant_mode", true);
        }
        if (entity.getData("fiskheroes:scale") <= 1) {
            manager.setData(entity, "fiskheroes:dyn/giant_mode", false);
        }
        if (entity.world().getDimension() == 2594) {
            manager.setData(entity, "fiskrework:dyn/quantum_scale", false);
        }
        if (PackLoader.getSide() == "SERVER" && entity.getData("fiskrework:dyn/size_slider_timer") > 0 && entity.getData("fiskrework:dyn/size_slider_timer") < 1 && entity.getData("fiskrework:dyn/quantum_scale")) {
            entity.as("PLAYER").addChatMessage("\u00A7cWARNING!! SIZE REGULATOR ALTERED, SHRINKING MAY RESULT IN \u00A7cYOU GOING SUBATOMIC");
        }
    });
}

function ruleModifier(entity, rule) {
	if (entity.getData("fiskrework:dyn/quantum_scale") && rule.name() == "fiskheroes:ticks_qrtimer") {
		return rule.value() - 1197
	}
    if (entity.getData("fiskrework:dyn/small_scale") && rule.name() == "fiskheroes:ticks_qrtimer") {
		return rule.value() + 2400
	}
    if (entity.getData("fiskrework:dyn/small_scale") && rule.name() == "fiskheroes:ticks_qrtimer") {
		return rule.value() + 1200
	}
    if (entity.getData("fiskrework:dyn/mini_scale") && rule.name() == "fiskheroes:ticks_qrtimer") {
		return rule.value() + 0
	}
    return null;
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:scale") > 1.5 ? entity.getData("fiskheroes:scale") > 5.0 ? 7 : 6 : 4;
}

function miniProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 0.0, 0);
    profile.addAttribute("BASE_SPEED", -0.6, 1);
    profile.addAttribute("SPRINT_SPEED", 0, 1);
}

function smallProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 0.5, 0);
    profile.addAttribute("BASE_SPEED", -0.4, 1);
    profile.addAttribute("SPRINT_SPEED", 0.05, 1);
}

function shortProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 0.5, 0);
    profile.addAttribute("BASE_SPEED", -0.2, 1);
    profile.addAttribute("SPRINT_SPEED", 0.1, 1);
}

function tallProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.5, 0);
    profile.addAttribute("FALL_RESISTANCE", 4.0, 0);
    profile.addAttribute("BASE_SPEED", -0.2, 1);
    profile.addAttribute("SPRINT_SPEED", 0.1, 1);
}

function largeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 2.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 4.0, 0);
    profile.addAttribute("BASE_SPEED", -0.4, 1);
    profile.addAttribute("SPRINT_SPEED", 0.05, 1);
}

function giantProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 3.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 7.0, 0);
    profile.addAttribute("BASE_SPEED", -0.8, 1);
    profile.addAttribute("SPRINT_SPEED", 0, 1);
}

function getProfile(entity) {
    if (entity.getData("fiskheroes:scale") < 1 && entity.getData("fiskheroes:scale") >= 0.5) {
        return "SHORT";
    } else if (entity.getData("fiskheroes:scale") < 0.5 && entity.getData("fiskheroes:scale") >= 0.15625) {
        return "SMALL";
    } else if (entity.getData("fiskheroes:scale") < 0.15625 && entity.getData("fiskheroes:scale") >= 0.0625) {
        return "MINI";
    } else if (entity.getData("fiskheroes:scale") <= 1.5 && entity.getData("fiskheroes:scale") > 1.0) {
        return "TALL";
    } else if (entity.getData("fiskheroes:scale") <= 5.0 && entity.getData("fiskheroes:scale") > 1.5) {
        return "LARGE";
    } else if (entity.getData("fiskheroes:scale") <= 7.5 && entity.getData("fiskheroes:scale") > 5.0) {
        return "GIANT";
    }
    return null;
}

function isModifierEnabled(entity, modifier) {
    var quantum = entity.getData("fiskrework:dyn/quantum_scale");
    var mini = entity.getData("fiskrework:dyn/mini_scale");
    var small = entity.getData("fiskrework:dyn/small_scale");
    var short = entity.getData("fiskrework:dyn/short_scale");
    var tall = entity.getData("fiskrework:dyn/tall_scale");
    var large = entity.getData("fiskrework:dyn/large_scale");
    var giant = entity.getData("fiskrework:dyn/giant_scale");
    switch (modifier.name()) {
        case "fiskheroes:size_manipulation":    //i need to improve this later on, it sucks
            switch (modifier.id()) {
            case "quantum":
                return (quantum && !mini && !small && !short && !tall && !large && !giant);
            case "mini":
                return (!quantum && mini && !small && !short && !tall && !large && !giant);
            case "small":
                return (!quantum && !mini && small && !short && !tall && !large && !giant);
            case "short":
                return (!quantum && !mini && !small && short && !tall && !large && !giant);
            case "tall":
                return (!quantum && !mini && !small && !short && tall && !large && !giant);
            case "large":
                return (!quantum && !mini && !small && !short && !tall && large && !giant);
            case "giant":
                return (!quantum && !mini && !small && !short && !tall && !large && giant);
            case "miniTall":
                return (!quantum && mini && !small && !short && tall && !large && !giant);
            case "miniLarge":
                return (!quantum && mini && !small && !short && !tall && large && !giant);
            case "miniGiant":
                return (!quantum && mini && !small && !short && !tall && !large && giant);
            case "smallTall":
                return (!quantum && !mini && small && !short && tall && !large && !giant);
            case "smallLarge":
                return (!quantum && !mini && small && !short && !tall && large && !giant);
            case "smallGiant":
                return (!quantum && !mini && small && !short && !tall && !large && giant);
            case "shortTall":
                return (!quantum && !mini && !small && short && tall && !large && !giant);
            case "shortLarge":
                return (!quantum && !mini && !small && short && !tall && large && !giant);
            case "shortGiant":
                return (!quantum && !mini && !small && short && !tall && !large && giant);
            };
        case "fiskheroes:cooldown":
            switch (modifier.id()) {
            case "tallCD":
                return (entity.getData("fiskheroes:scale") <= 1.5);
            case "largeCD":
                return (entity.getData("fiskheroes:scale") <= 5.0 && entity.getData("fiskheroes:scale") > 1.5);
            case "giantCD":
                return (entity.getData("fiskheroes:scale") > 5.0);
            };
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    var quantum = entity.getData("fiskrework:dyn/quantum_scale");
    var mini = entity.getData("fiskrework:dyn/mini_scale");
    var small = entity.getData("fiskrework:dyn/small_scale");
    var short = entity.getData("fiskrework:dyn/short_scale");
    var tall = entity.getData("fiskrework:dyn/tall_scale");
    var large = entity.getData("fiskrework:dyn/large_scale");
    var giant = entity.getData("fiskrework:dyn/giant_scale");
    var all = entity.getData("fiskrework:dyn/mini_scale") && entity.getData("fiskrework:dyn/small_scale") && entity.getData("fiskrework:dyn/large_scale") && entity.getData("fiskrework:dyn/giant_scale");
    switch (keyBind) {
    case "SIZE_MANIPULATION":
        return !entity.getData("fiskrework:dyn/size_slider");
    case "QUANTUM":
        return entity.getData("fiskrework:dyn/size_slider") && entity.isSneaking() && entity.getData("fiskheroes:scale") >= 1 && (!all || quantum) && !(mini || small || short || tall || large || giant || mini && tall || mini && large || mini && giant || small && tall || small && large || small && giant || short && tall || short && large || short && giant);
    case "MINI":
        return entity.getData("fiskrework:dyn/size_slider") && !entity.isSneaking() && entity.getData("fiskheroes:scale") >= 1 && (!all || mini || mini && tall || mini && large || mini && giant) && !(quantum || small || short || small && tall || small && large || small && giant || short && tall || short && large || short && giant);
    case "SMALL":
        return entity.getData("fiskrework:dyn/size_slider") && !entity.isSneaking() && entity.getData("fiskheroes:scale") >= 1 && (!all || small || small && tall || small && large || small && giant) && !(quantum || mini || short || mini && tall || mini && large || mini && giant || short && tall || short && large || short && giant);
    case "SHORT":
        return entity.getData("fiskrework:dyn/size_slider") && entity.isSneaking() && entity.getData("fiskheroes:scale") >= 1 && (!all || short || short && tall || short && large || short && giant) && !(quantum || mini || small || mini && tall || mini && large || mini && giant || small && tall || small && large || small && giant);
    case "TALL":
        return entity.getData("fiskrework:dyn/size_slider") && entity.isSneaking() && entity.getData("fiskheroes:scale") <= 1 && (!all || tall || mini && tall || small && tall || short && tall) && !(quantum || large || giant || mini && large || mini && giant || small && large || small && giant || short && large || short && giant);
    case "LARGE":
        return entity.getData("fiskrework:dyn/size_slider") && !entity.isSneaking() && entity.getData("fiskheroes:scale") <= 1 && (!all || large || mini && large || small && large || short && large) && !(quantum || tall || giant || mini && tall || mini && giant || small && tall || small && giant || short && tall || short && giant);
    case "GIANT":
        return entity.getData("fiskrework:dyn/size_slider") && !entity.isSneaking() && entity.getData("fiskheroes:scale") <= 1 && (!all || giant || mini && giant || small && giant || short && giant) && !(quantum || tall || large || mini && tall || mini && large || small && tall || small && large || short && tall || short && large);
    default:
        return true;    //i also need to improve these, they suck
    }
}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}