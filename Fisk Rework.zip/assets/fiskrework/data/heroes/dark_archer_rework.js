function init(hero) {
    hero.setName("hero.fiskheroes.dark_archer.name");
    hero.setVersion("Rework")
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.hood");
    hero.setChestplate("item.superhero_armor.piece.robes");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:scimitar", true);
    hero.addEquipment("fiskheroes:compound_bow");
    hero.addEquipment("fiskheroes:quiver");

    hero.addPowers("fiskrework:archery_rework", "fiskheroes:smoke_bombs");
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);
    hero.addAttribute("BOW_DRAWBACK", 0.65, 1);

    hero.addKeyBind("QUIVER_CYCLE", "key.quiverCycle", 1);
    hero.addKeyBind("HORIZONTAL_BOW", "key.horizontalBow", 2);
    hero.addKeyBind("UTILITY_BELT", "key.smokeBombs", 3);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_CLOSE", "fiskrework:hood_up");
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addAttributeProfile("BOW", bowProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setAttributeProfile(getAttributeProfile);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "QUIVER_CYCLE":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    case "HORIZONTAL_BOW":
        return entity.getHeldItem().name() == "fiskheroes:compound_bow";
    default:
        return true;
    }
}

function getAttributeProfile(entity) {
    return (entity.getHeldItem().name() === "fiskheroes:compound_bow" || entity.getHeldItem().name() === "minecraft:bow") && entity.as('PLAYER').isUsingItem() ? "BOW" : null;
}

function bowProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 0.95, 1);
}