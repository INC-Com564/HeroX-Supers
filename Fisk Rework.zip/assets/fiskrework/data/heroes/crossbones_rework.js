function init(hero) {
    hero.setName("hero.fiskheroes.crossbones.name");
    hero.setVersion("Rework");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:charge_gauntlets", "fiskheroes:pain_resistance", "fiskheroes:grenades");
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("MAX_HEALTH", 2.0, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "key.grenades", 1);
    hero.addKeyBind("CHARGED_PUNCH", "key.punchToggle", 1);
    hero.addKeyBind("BLADE", "Toggle Blade", 2);

    hero.addAttributeProfile("PUNCH", punchProfile);
    hero.addAttributeProfile("BLUNT", bluntProfile);
    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun() && !entity.getData("fiskheroes:punchmode"));
    hero.addDamageProfile("BLADE", {"types": {"SHARP": 1.0}});
    hero.addDamageProfile("BLUNT", {"types": {"BLUNT": 1.0}});
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:blade":
            return entity.getData("fiskheroes:punch_charged");
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming") && !entity.isSneaking() && !entity.getData("fiskheroes:punchmode");
    case "UTILITY_BELT":
        return !entity.getData("fiskheroes:punchmode") && entity.isSneaking();
    case "CHARGED_PUNCH":
        return entity.getData("fiskheroes:utility_belt_type") == -1 && !entity.isSneaking() && !entity.getHeldItem().isGun();
    case "BLADE":
        return entity.getData("fiskheroes:punch_charged");
    default:
        return true
    }
  }

function punchProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    profile.addAttribute("KNOCKBACK", 2.5, 0);
}

function bluntProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    profile.addAttribute("FALL_RESISTANCE", 3.5, 0);
    profile.addAttribute("BASE_SPEED", -0.2, 1);
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    profile.addAttribute("REACH_DISTANCE", 0.5, 0);
}

function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:punchmode") ? entity.getData("fiskheroes:punch_charged") ? entity.getData("fiskheroes:blade") ? "BLADE" : "PUNCH" : "BLUNT" : null;
}