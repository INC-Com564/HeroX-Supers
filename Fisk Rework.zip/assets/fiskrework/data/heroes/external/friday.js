var canTalk = true;
var cantTalk = true;

function helloWorld(entity, manager) {
    var friday = (entity.getData("fiskrework:dyn/friday"));
    var ask = (entity.getData("fiskheroes:ticks_since_gunshot") > 0 && friday)
    var hello = "\u00A7d<F.R.I.D.A.Y.> Hello boss, I'm here to assist"
    if (friday == true && ask == true) {
        PackLoader.printChat(hello);
    }
    else if (!ask && !friday) {
        var ask = true
    }
}

