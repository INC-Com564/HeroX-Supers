var speedster_base = implement("fiskheroes:external/speedster_base");
function init(hero) {
    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);
    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);
    hero.addKeyBind("EFFECT_CLEAR", "Clear System", 4);
    hero.addKeyBind("INTANGIBILITY", "Phase", 5);
    hero.addKeyBind("INVIS", "Vibrate", 5);

    var speedPunch = speedster_base.createSpeedPunch(hero);
    hero.setDamageProfile(entity => speedPunch.get(entity, null));

    hero.addAttributeProfile("INVIS", invisProfile);
    hero.addAttributeProfile("CLEAR", clearProfile);
    hero.addAttributeProfile("WIND", windFunnelProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setTickHandler((entity, manager) => {
        speedster_base.tick(entity, manager);
        if (entity.getData("fiskrework:dyn/speed_force_invis_timer") == 1) {
            manager.setData(entity, "fiskheroes:invisible", true);
        }
    });
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskrework:dyn/effect_clear")) {
      return "CLEAR";
    }
    else if (entity.getData("fiskheroes:beam_shooting_timer") > 0) {
        return "WIND";
    }
    return entity.getData("fiskrework:dyn/speed_force_invis_timer") > 0 ? "INVIS": null;
}

function clearProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function invisProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function windFunnelProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}
