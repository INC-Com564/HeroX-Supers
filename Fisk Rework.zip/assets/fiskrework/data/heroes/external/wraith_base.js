function makeSounds(slowMotion, controlledFlight) {
    return {
        "controlledFlight": controlledFlight,
        "slowMotion": {
            "ENABLE": "fiskheroes:slow_motion_enable_" + slowMotion,
            "DISABLE": "fiskheroes:slow_motion_disable_" + slowMotion
        }
    };
}

var SOUNDS_BARRY = makeSounds("cw", {
    "BOOST": ["fiskrework:time_wraith_boost", "fiskrework:wraith_move_cw", "fiskrework:wraith_boost_barry"]
});
// var SOUNDS_TEST = makeSounds("cw", {
//     "MOVE": "fiskheroes:super_speed_move_loop_barry_test",
//     "SPRINT": "fiskheroes:super_speed_sprint_barry_test",
//     "STOP": "fiskheroes:super_speed_stop_barry_test"
// });
var SOUNDS_KF = makeSounds("cw", {
    "BOOST": ["fiskrework:time_wraith_boost", "fiskrework:wraith_move_cw", "fiskrework:wraith_boost_wally"]
});
// var SOUNDS_JAY = makeSounds("cw", {
//     "MOVE": "fiskheroes:super_speed_move_loop_cw",
//     "SPRINT": "fiskheroes:super_speed_sprint_jay",
//     "STOP": "fiskheroes:super_speed_stop_jay"
// });
var SOUNDS_NEGATIVE = makeSounds("cw", {
    "BOOST": ["fiskrework:time_wraith_boost", "fiskrework:wraith_move_cw", "fiskrework:wraith_boost_negative"]
});
var SOUNDS_ZOOM = makeSounds("cw", {
    "BOOST": ["fiskrework:time_wraith_boost", "fiskrework:wraith_move_cw", "fiskrework:wraith_boost_zoom"]
});
// var SOUNDS_DEATH = makeSounds("cw", {
//     "MOVE": "fiskheroes:super_speed_move_loop_cw",
//     "SPRINT": ["fiskheroes:super_speed_sprint_zoom_death", "fiskheroes:super_speed_sprint_zoom_death_noise", "fiskheroes:super_speed_sprint_negative_roar"],
//     "STOP": ["fiskheroes:super_speed_stop_zoom_death", "fiskheroes:super_speed_stop_zoom_death_noise", "fiskheroes:super_speed_stop_negative_roar", "fiskheroes:super_speed_stop_zoom_death_roar"]
// });
// var SOUNDS_PINK = makeSounds("cw", {
//     "MOVE": "fiskheroes:super_speed_move_loop_zoom_pink",
//     "SPRINT": "fiskheroes:super_speed_sprint_zoom_pink",
//     "STOP": "fiskheroes:super_speed_stop_zoom_pink"
// });
// var SOUNDS_SAVITAR = makeSounds("cw", {
//     "MOVE": ["fiskheroes:super_speed_move_loop_cw", "fiskheroes:super_speed_move_loop_savitar"],
//     "SPRINT": ["fiskheroes:super_speed_sprint_savitar", "fiskheroes:super_speed_sprint_savitar_noise"],
//     "STOP": ["fiskheroes:super_speed_stop_savitar", "fiskheroes:super_speed_stop_savitar_noise"]
// });
// var SOUNDS_RGB = makeSounds("cw", {
//     "MOVE": ["fiskheroes:super_speed_move_loop_cw", "fiskheroes:super_speed_move_loop_savitar_rgb"],
//     "SPRINT": ["fiskheroes:super_speed_sprint_savitar", "fiskheroes:super_speed_sprint_savitar_noise"],
//     "STOP": ["fiskheroes:super_speed_stop_savitar", "fiskheroes:super_speed_stop_savitar_noise"]
// });

var SOUNDS_COMICS = makeSounds("comics", {
    "BOOST": ["fiskrework:time_wraith_boost", "fiskrework:wraith_move_comics", "fiskrework:wraith_boost_comics"]
});

function tick(entity, manager) {
    manager.incrementData(entity, "fiskheroes:dyn/flight_super_boost", 4, entity.isSprinting() && entity.getData("fiskheroes:flight_boost_timer"));
}

function createSpeedPunch(hero, damageProfile) {
    if (typeof damageProfile === "undefined") {
        damageProfile = {
            "types": {
                "BLUNT": 1.0
            },
            "properties": {
                "HIT_COOLDOWN": 5
            }
        };
    }

    hero.addDamageProfile("SPEED_PUNCH", damageProfile);
    return {
        get: (entity, orElse) => entity.getData("fiskheroes:speeding") ? "SPEED_PUNCH" : orElse
    };
}

function mergeSounds(powerName, sounds, profile) {
    var profile2 = { "powers": {} };
    profile2.powers[powerName] = {
        "fiskheroes:slow_motion": sounds.slowMotion,
        "fiskheroes:controlled_flight|boosted": sounds.controlledFlight
    };
    if (typeof profile === "undefined") {
        return profile2;
    }
    return merge(profile, profile2);
}

function merge(from, into) {
    if (typeof from !== "object") {
        return from;
    }
    var result = {};
    for (var attrname in into) {
        result[attrname] = into[attrname];
    }
    for (var attrname in from) {
        if (result.hasOwnProperty(attrname)) {
            result[attrname] = merge(from[attrname], result[attrname]);
        }
        else {
            result[attrname] = from[attrname];
        }
    }
    return result;
}
