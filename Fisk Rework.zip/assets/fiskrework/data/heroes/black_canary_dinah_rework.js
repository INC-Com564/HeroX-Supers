function init(hero) {
    hero.setName("hero.fiskheroes.black_canary_dinah.name");
    hero.setVersion("Rework");
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:bo_staff", true);

    hero.addPowers("fiskrework:canary_cry_rework");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("CHARGED_BEAM", "key.canaryCry", 1);
    hero.addKeyBind("SONIC_WAVES", "key.canaryCry", 1);

    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun());
    hero.setHasPermission((entity, permission) => permission == "USE_GUN");
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return entity.getHeldItem().isGun() && !entity.getData("fiskheroes:aiming");
    case "CHARGED_BEAM":
        return !entity.getHeldItem().isGun();
    default:
        return true;
    }
}


function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:sonic_waves":
            return entity.getData("fiskheroes:beam_shooting_timer") > 0;
        default:
            return true;
    }
}