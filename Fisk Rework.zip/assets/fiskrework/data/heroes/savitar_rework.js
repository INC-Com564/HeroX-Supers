var speedster_base = implement("fiskheroes:external/speedster_base");

function init(hero) {
    hero.setName("hero.fiskheroes.savitar.name");
    hero.setVersion("Rework")
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:flash_ring");

    hero.addPowers("fiskrework:speed_force_rework", "fiskheroes:savitar_armor");
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 0.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.5, 0);
    hero.addAttribute("BASE_SPEED_LEVELS", 7.0, 0);

    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);
    hero.addKeyBind("BLADE", "key.spike", 3);
    hero.addKeyBind("CHARGED_BEAM", "Wind Funnel", 3);
    hero.addKeyBind("EFFECT_CLEAR", "Clear System", 4);
    hero.addKeyBind("INTANGIBILITY", "Phase", 5);
    hero.addKeyBind("INVIS", "Vibrate", 5);

    hero.setDefaultScale(1.2);
    hero.setHasProperty((entity, property) => property == "BREATHE_SPACE");

    var speedPunch = speedster_base.createSpeedPunch(hero, {
        "types": {
            "BLUNT": 1.0,
            "SHARP": 0.2
        },
        "properties": {
            "HIT_COOLDOWN": 5
        }
    });
    hero.setDamageProfile(entity => entity.getData("fiskheroes:blade") ? "BLADE" : speedPunch.get(entity, null));
    hero.addDamageProfile("BLADE", { "types": { "SHARP": 1.0 } });

    hero.addSoundEvent("LAND", "fiskheroes:savitar_land");
    hero.addSoundEvent("STEP", ["fiskheroes:savitar_walk1", "fiskheroes:savitar_walk2", "fiskheroes:savitar_sprint"]);
    hero.addSoundOverrides("SAVITAR", speedster_base.mergeSounds("fiskrework:speed_force_rework", speedster_base.SOUNDS_SAVITAR));
    hero.addSoundOverrides("BARRY", speedster_base.mergeSounds("fiskrework:speed_force_rework", speedster_base.SOUNDS_BARRY));
    hero.addSoundOverrides("RGB", speedster_base.mergeSounds("fiskrework:speed_force_rework", speedster_base.SOUNDS_RGB));

    hero.addAttributeProfile("INVIS", invisProfile);
    hero.addAttributeProfile("CLEAR", clearProfile);
    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.addAttributeProfile("WIND", windFunnelProfile);
    hero.addDamageProfile("BLADE", { "types": { "SHARP": 1.0 } });
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.setTickHandler((entity, manager) => {
        speedster_base.tick(entity, manager);
        if (entity.getData("fiskrework:dyn/speed_force_invis_timer") == 1) {
            manager.setData(entity, "fiskheroes:invisible", true);
        }
    });
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskrework:dyn/effect_clear")) {
      return "CLEAR";
    }
    else if (entity.getData("fiskheroes:blade")) {
      return "BLADE"
    }
    else if (entity.getData("fiskheroes:beam_shooting_timer") > 0) {
        return "WIND";
    }
    return entity.getData("fiskheroes:invisible") ? "INVIS": null;
}

function clearProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1.5, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 8.0, 0);
}

function invisProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1.5, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function windFunnelProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -1.5, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:invisibility":
        return entity.getData("fiskrework:dyn/speed_force_invis");
    case "fiskheroes:damage_immunity":
        return modifier.id() == "catch3" == (entity.getData("fiskrework:dyn/bullet_catch"));
    case "fiskheroes:potion_immunity":
        return modifier.id() == "vibrate3" == (entity.getData("fiskrework:dyn/effect_clear"));
    case "fiskheroes:lightning_cast":
        return entity.isSprinting() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && !entity.getData("fiskheroes:beam_shooting");
    case "fiskheroes:blade":
        return !entity.getData("fiskrework:dyn/speed_force_invis") && !entity.getData("fiskrework:dyn/effect_clear") && !entity.getData("fiskheroes:intangibility_timer");
    case "fiskheroes:arrow_catching":
        return entity.isPunching();
    case "fiskheroes:charged_beam":
        switch (modifier.id()) {
        case "wind_funnel":
            return (!entity.getData("fiskheroes:aiming"));
        case "speed_steal":
            return (entity.getData("fiskheroes:aiming"));
            };
    case "fiskheroes:flight":
        return entity.isInWater() && !entity.isSneaking() && entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && (entity.world().blockAt(entity.pos().subtract(0,0.05,0)).isSolid());
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "EFFECT_CLEAR":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 3 && entity.isOnGround() && !entity.getData("fiskrework:dyn/effect_clear_cooldown") >=1;
    case "BULLET_CATCH":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && !entity.getData("fiskrework:dyn/bullet_catch_cooldown") >=1;
    case "BLADE":
        return !entity.getData("fiskheroes:speeding") || entity.getData("fiskheroes:speed") <= 3 || entity.isSneaking() || entity.getData("fiskheroes:blade");
    case "CHARGED_BEAM":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 4 && entity.isOnGround() && !entity.isSneaking() && !entity.getData("fiskheroes:blade");
    case "INTANGIBILITY":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 5 && !entity.isOnGround() && !entity.getData("fiskheroes:dyn/intangibility_cooldown") >=1;
    case "INVIS":
        return entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:speed") >= 7 && entity.isOnGround() && !entity.getData("fiskrework:dyn/speed_force_invis_cooldown") >=1 || entity.getData("fiskrework:dyn/speed_force_invis");
    default:
        return true;
    }
}
