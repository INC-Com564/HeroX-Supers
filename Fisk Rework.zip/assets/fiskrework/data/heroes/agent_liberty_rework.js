function init(hero) {
    hero.setName("hero.fiskheroes.agent_liberty.name");
    hero.setVersion("Rework");
    hero.setTier(4);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskheroes:retractable_blade", "fiskrework:harun_el_mutation");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 2.5, 0);

    hero.addKeyBind("BLADE", "key.blade", 1);
    hero.addKeyBind("TRANSFORM", "Inject Serum", 4);

    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.addAttributeProfile("SERUM", serumProfile);
    hero.setAttributeProfile(getProfile);
    hero.addDamageProfile("BLADE", {"types": {"SHARP": 1.0}});
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setTierOverride(getTierOverride);
}

function getTierOverride(entity) {
    return entity.getData("fiskrework:dyn/serum") ? 8 : 4;
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "BLADE":
            return !entity.getData("fiskrework:dyn/serum");
        case "TRANSFORM":
            return !entity.getData("fiskheroes:blade") && !entity.getData("fiskrework:dyn/serum_cooldown") && !entity.getData("fiskrework:dyn/serum_timer");
        default:
            return true;
}}    

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 7.0, 0);
}

function serumProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    profile.addAttribute("SPRINT_SPEED", 0.6, 1);
    profile.addAttribute("JUMP_HEIGHT", 2.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 8.0, 0);
    profile.addAttribute("STEP_HEIGHT", 0.5, 0);
}

function getProfile(entity) {
    return entity.getData("fiskheroes:blade") ? "BLADE" : entity.getData("fiskrework:dyn/serum") ? "SERUM" : null
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:leaping":
            return entity.getData("fiskrework:dyn/serum");
        case "fiskheroes:regeneration":
            return entity.getData("fiskrework:dyn/serum");
        case "fiskheroes:projectile_immunity":
            return entity.getData("fiskrework:dyn/serum");
        case "fiskheroes:potion_immunity":
            return entity.getData("fiskrework:dyn/serum");
        default:
            return true;
    }
}