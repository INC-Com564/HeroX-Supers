var utils = implement("fiskheroes:external/utils");

function init(hero) {
    hero.setName("hero.fiskheroes.doctor_strange.name");
    hero.setVersion("Rework");
    hero.setAliases("strange");
    hero.setTier(2);

    hero.setChestplate("item.superhero_armor.piece.robes");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskheroes:cloak_of_levitation", "fiskrework:eldritch_magic_rework");
    hero.addAttribute("PUNCH_DAMAGE", 1.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("BLADE", "key.blade", 1);
    hero.addKeyBind("SHIELD", "key.shield", 1);
    hero.addKeyBind("SPELL_MENU", "key.spellMenu", 2);
    hero.addKeyBind("UTILITY_BELT", "Quick Spells", 3);
    hero.addKeyBind("TELEPORT", "Sling Ring", 3);
    hero.addKeyBind("INTANGIBILITY", "Astral Projection", 4);
    hero.addKeyBind("FLAME", "Toggle Bolts Of Balthaak/Flames of Faltine", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);

    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDamageProfile(getProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "FIRE": 0.2
        }
    });

    hero.setTickHandler((entity, manager) => {
        if (!entity.isSneaking() && !entity.isOnGround() && entity.motionY() < -0.8) {
            manager.setData(entity, "fiskheroes:flying", true);
        }
        utils.flightOnIntangibility(entity, manager);
    });
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 7.0, 0);
}

function getProfile(entity) {
    return entity.getData("fiskheroes:blade") ? "BLADE" : null;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:shield":
            return !entity.getData("fiskheroes:blade") && !entity.getData("fiskheroes:intangible");
        case "fiskheroes:equipment":
            return !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:intangible");
        case "fiskheroes:lightning_cast":
            return !entity.getData("fiskrework:dyn/flame_of_faltine") && !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:intangible") && !entity.getData("fiskheroes:blade") && entity.getData("fiskheroes:utility_belt_type") == -1;
        case "fiskheroes:fireball":
            return entity.getData("fiskrework:dyn/flame_of_faltine") && !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:intangible") && !entity.getData("fiskheroes:blade") && entity.getData("fiskheroes:utility_belt_type") == -1;
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "SHIELD":
        return !entity.getData("fiskheroes:intangible") && (!entity.getData("fiskheroes:shield") || !entity.getData("fiskheroes:aiming"));
    case "BLADE":
        return entity.getData("fiskheroes:shield") && entity.getData("fiskheroes:aiming") || entity.getData("fiskheroes:blade") || entity.isBookPlayer();
    case "SPELL_MENU":
        return !entity.getData("fiskheroes:blade") && !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:intangible");
    case "UTILITY_BELT":
        return !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:blade") && !entity.getData("fiskheroes:intangible");
    case "TELEPORT":
        return entity.getData("fiskheroes:shield") && entity.getData("fiskheroes:aiming");
    case "INTANGIBILITY":
        return !entity.getData("fiskheroes:shield") && !entity.getData("fiskheroes:blade");
    default:
        return true;
    }
}

function canAim(entity) {
    return entity.getData("fiskheroes:shield") && entity.getData("fiskheroes:shield_blocking_timer") == 0;
}
