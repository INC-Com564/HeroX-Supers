var landing = implement("fiskrework:external/superhero_swing_landing");

function init(hero) {
    hero.setName("Spider-Man/MCU");
    hero.setVersion("Rework");
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:spider_physiology_rework", "fiskrework:web_shooters_rework", "fiskrework:stark_tech_suit");
    hero.addAttribute("FALL_RESISTANCE", 12.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.5, 0);
    hero.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.45, 1);
    hero.addAttribute("STEP_HEIGHT", 0.5, 0);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("UTILITY_BELT", "key.webShooters", 1);
    hero.addKeyBind("WEBS", "Cycle Web Types", 1);
    hero.addKeyBind("WEB_ZIP", "key.webZip", 2);
    hero.addKeyBindFunc("func_WEB_SWINGING", webSwingingKey, "key.webSwinging", 3);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotionHold", 4);
    hero.addKeyBindFunc("ENHANCED_COMBAT", combatKey, "Activate Enhanced Combat", 5);
    hero.addKeyBindFunc("func_WEB_WINGS", webWingsKey, "key.webWings", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setDamageProfile(getAttributeProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.addAttributeProfile("LAND", landProfile);
    hero.addDamageProfile("ENHANCED_COMBAT", {"properties":{"HIT_COOLDOWN": 7}});

    hero.setTickHandler((entity, manager) => {
        if (!entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 7, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));;
        }
        else if (entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 30, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));
        }
        manager.incrementData(entity, "fiskrework:dyn/perch_timer", 6, entity.getData("fiskrework:dyn/sneaking_timer") == 1);
        
        landing.tick(entity, manager);
     });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:web_swinging":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:utility_belt_type") == -1 && !entity.getData("fiskheroes:gliding");
    case "fiskheroes:web_zip":
        return !entity.getData("fiskheroes:gliding");
    case "fiskheroes:arrow_catching":
        return entity.isPunching() || entity.getData("fiskheroes:slow_motion");
    case "fiskheroes:leaping":
        return modifier.id() == "springboard" == (entity.getData("fiskheroes:ticks_since_swinging") < 5);
    case "fiskheroes:gliding":
        return !entity.getData("fiskrework:dyn/enhanced_combat") && !entity.getData("fiskheroes:web_swinging") && entity.getData("fiskheroes:utility_belt_type") == -1 && !entity.as("PLAYER").isUsingItem();
    case "fiskheroes:equipment":
        switch (modifier.id()) {
        case "basic":
            return (!entity.getData("fiskrework:dyn/special_webs") && !entity.getData("fiskrework:dyn/enhanced_combat"));
        case "enhanced_combat":
            return (!entity.getData("fiskrework:dyn/special_webs") && entity.getData("fiskrework:dyn/enhanced_combat"));
        case "special":
            return (entity.getData("fiskrework:dyn/special_webs") && !entity.getData("fiskrework:dyn/enhanced_combat"));
        case "special_enhanced_combat":
            return (entity.getData("fiskrework:dyn/special_webs") && entity.getData("fiskrework:dyn/enhanced_combat"));
        };
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "func_WEB_SWINGING":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskrework:dyn/enhanced_combat");
    case "func_WEB_WINGS":
        return !entity.isOnGround() && !entity.isInWater() && !entity.isSneaking() && !entity.as("PLAYER").isUsingItem() && !entity.getData("fiskrework:dyn/enhanced_combat");
    case "WEB_ZIP":
        return !entity.getData("fiskheroes:gliding") && !entity.getData("fiskrework:dyn/enhanced_combat");
    case "UTILITY_BELT":
        return !entity.isSneaking() || entity.getData("fiskrework:dyn/sneaking_timer") == 1;
    case "WEBS":
        return entity.isSneaking() && entity.getData("fiskrework:dyn/sneaking_timer") < 1;
    case "ENHANCED_COMBAT":
        return (!entity.getData("fiskheroes:web_swinging") && !entity.getData("fiskheroes:gliding")) && (entity.isOnGround() || entity.isSneaking()) || entity.getData("fiskrework:dyn/enhanced_combat");
    default:
        return true;
    }
}


function webSwingingKey(player, manager) {
    var flag = player.getData("fiskheroes:web_swinging");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
        manager.setDataWithNotify(player, "fiskheroes:gliding", false);
        manager.setDataWithNotify(player, "fiskrework:dyn/enhanced_combat", false);
    }

    manager.setDataWithNotify(player, "fiskheroes:web_swinging", !flag);
    return true;
}

function webWingsKey(player, manager) {
    if (player.isOnGround() || player.isInWater()) {
        return false;
    }

    var flag = player.getData("fiskheroes:gliding");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
        manager.setDataWithNotify(player, "fiskheroes:web_swinging", false);
        manager.setDataWithNotify(player, "fiskrework:dyn/enhanced_combat", false);
    }

    manager.setDataWithNotify(player, "fiskheroes:gliding", !flag);
    return true;
}

function combatKey(player, manager) {
    if (player.isOnGround() || player.isInWater() || player.isSneaking()) {
        return true;
    }

    var flag = player.getData("fiskrework:dyn/enhanced_combat");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
        manager.setDataWithNotify(player, "fiskheroes:web_swinging", false);
        manager.setDataWithNotify(player, "fiskheroes:gliding", false);
    }

    manager.setDataWithNotify(player, "fiskrework:dyn/enhanced_combat", !flag);
    return true;
}

function landProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 24.0, 0);
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskrework:dyn/enhanced_combat")) {
        return "ENHANCED_COMBAT";
    }
    else if (entity.getData("fiskheroes:dyn/superhero_landing_timer") > 0) {
        return "LAND";
    }
}