var utils = implement("fiskheroes:external/utils");

function init(hero) {
    hero.setName("hero.fiskheroes.vision.name");
    hero.setVersion("Rework");
    hero.setTier(9);

    hero.setHelmet("item.superhero_armor.piece.head");
    hero.setChestplate("item.superhero_armor.piece.torso");
    hero.setLeggings("item.superhero_armor.piece.legs");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:vibranium_physiology_rework", "fiskrework:mind_stone_rework");
    hero.addAttribute("PUNCH_DAMAGE", 10.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);

    hero.addKeyBind("CHARGED_BEAM", "key.mindStoneBlast", 1);
    hero.addKeyBind("AIM", "Ready Mind Stone", 2)
    hero.addKeyBind("INTANGIBILITY", "key.intangibility", 3);
    hero.addKeyBind("DENSITY_UP", "Increase Density", 4);
    hero.addKeyBind("DISGUISE", "Human Disguise", 5);

    hero.supplyFunction("canAim", canAim);
    hero.setHasProperty(hasProperty);
    hero.setTierOverride(getTierOverride);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setAttributeProfile(getAttributeProfile);
    hero.addAttributeProfile("INTANGIBLE", phaseProfile);
    hero.addAttributeProfile("DENSE", denseProfile);

    hero.setTickHandler((entity, manager) => {
        utils.flightOnIntangibility(entity, manager);

        if (entity.getData("fiskrework:dyn/dense_timer") == 1) {
            manager.setData(entity, "fiskheroes:flying", false);
        }

        if (entity.getData("fiskrework:dyn/dense") && entity.getData("fiskrework:dyn/dense_timer") < 1) {
            manager.setData(entity, "fiskheroes:intangible", false);
        }
        if (entity.getData("fiskheroes:intangible") && entity.getData("fiskheroes:intangibility_timer") < 1) {
            manager.setData(entity, "fiskrework:dyn/dense", false);
        }
    });
}

function getTierOverride(entity) {
    return entity.getData("fiskrework:dyn/dense") ? 10 : entity.getData("fiskheroes:intangible") ? 8 : 9;
}

function phaseProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    profile.addAttribute("WEAPON_DAMAGE", 0.0, 0);
    profile.addAttribute("IMPACT_DAMAGE", 0.25, 0);
    profile.addAttribute("BASE_SPEED", 0.15, 1);
    profile.addAttribute("JUMP_HEIGHT", 2.0, 0);
}

function denseProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 13.0, 0);
    profile.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    profile.addAttribute("IMPACT_DAMAGE", 0.75, 0);
    profile.addAttribute("BASE_SPEED", -0.8, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskheroes:intangible")) {
        return "INTANGIBLE";
    } else if (entity.getData("fiskrework:dyn/dense")) {
        return "DENSE";
    }
    return null
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        switch (modifier.id()) {
        case "baseFlight":
            return (!entity.getData("fiskheroes:intangible") && !entity.getData("fiskrework:dyn/dense") && !entity.getData("fiskrework:dyn/disguise"));
        case "intangibleFlight":
            return (entity.getData("fiskheroes:intangible") && !entity.getData("fiskrework:dyn/dense") && !entity.getData("fiskrework:dyn/disguise"));
        };
    case "fiskheroes:damage_resistance":
        switch (modifier.id()) {
        case "blastResist":
            return !entity.getData("fiskheroes:intangible");
        case "fireResist":
            return !entity.getData("fiskheroes:intangible");
        case "bulletResist":
            return entity.getData("fiskheroes:intangible");
        };
    case "fiskheroes:damage_immunity":
        switch (modifier.id()) {
        case "blastImmune":
            return entity.getData("fiskrework:dyn/dense");
        case "fireImmune":
            return entity.getData("fiskrework:dyn/dense");
        };
    case "fiskheroes:projectile_immunity":
        return !entity.getData("fiskheroes:intangible");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "AIM":
        return entity.getData("fiskheroes:beam_charge") == 0;
    case "CHARGED_BEAM":
        return entity.getData("fiskheroes:aiming_timer") == 0;
    case "DENSITY_UP":
        return entity.getData("fiskrework:dyn/disguise_timer") == 0;
    case "INTANGIBILITY":
        return entity.getData("fiskrework:dyn/disguise_timer") == 0;
    default:
        return true;
    }
}

function hasProperty(property) {
    return property == "BREATHE_SPACE";
}

function canAim(entity) {
    return !entity.getData("fiskheroes:intangible");
}