function init(hero) {
    hero.setName("Shazam/DCEU");
    hero.setVersion("Rework");
    hero.setTier(9);

    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:divine_empowerment_rework");
    hero.addAttribute("PUNCH_DAMAGE", 10.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.7, 1);
    hero.addAttribute("JUMP_HEIGHT", 1.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);
    hero.addAttribute("BASE_SPEED_LEVELS", 2.0, 0);

    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("HEAT_VISION", "Lightning Blast", 2);
    hero.addKeyBind("SHAZAM", "SHAZAM!!", 5);

    hero.setDefaultScale(shazamScale);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setTierOverride(getTierOverride);
    hero.addAttributeProfile("INACTIVE", inactiveProfile);
    hero.addAttributeProfile("ETERNIUM", eterniumProfile);
    hero.addAttributeProfile("LIGHTNING_SPEED", lightningSpeedProfile);
    hero.setAttributeProfile(getProfile);

    hero.addDamageProfile("SHAZAM_LIGHTNING", {
        "types": {
          "ELECTRICITY": 1.0,
          "MAGIC": 1.0
        },
        "properties": {
          "COOK_ENTITY": true,
          "REDUCE_KNOCKBACK": 1.0,
          "HEAT_TRANSFER": 75,
          "LIGHTNING_STRIKE": 1.0
        }
    });
    hero.setDamageProfile(entity => (!entity.getHeldItem().isWeapon() && entity.getData("fiskrework:dyn/shazam")) ? "PUNCH" : null);
    hero.addDamageProfile("PUNCH", {
        "types": {
            "BLUNT": 1.0,
            "MAGIC": 0.7
        }
    });

    hero.setTickHandler((entity, manager) => {
        manager.incrementData(entity, "fiskheroes:dyn/speed_sprint_timer", 4, entity.isSprinting() && entity.getData("fiskheroes:speed_sprinting") && entity.getData("fiskheroes:speed") >= 1);

        if (!entity.isOnGround() && entity.motionY() < -0.05 && entity.getData("fiskrework:dyn/shazam_timer") >= 0.8 && entity.getData("fiskrework:dyn/shazam_timer") < 1) {
            manager.setData(entity, "fiskheroes:flying", true);
        }
    });
}

function inactiveProfile(profile) {
    profile.revokeAugments();
    profile.addAttribute("MAX_HEALTH", -5.0, 0);
}

function lightningSpeedProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED_LEVELS", 1.0, 0);
}

function eterniumProfile(profile) {
    profile.inheritDefaults();
    profile.revokeAugments();
    profile.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    profile.addAttribute("SPRINT_SPEED", 0.2, 1);
    profile.addAttribute("FALL_RESISTANCE", 5.0, 0);
}

function shazamScale(entity) {
    if (entity.getData("fiskrework:dyn/shazam") || entity.is("DISPLAY")) {
        return 1.1;
    }
    return 0.7;
}

function getProfile(entity) {
    if (!entity.getData("fiskrework:dyn/shazam")) {
        return "INACTIVE";
    }
    if (entity.getData("fiskheroes:speeding") && entity.getData("fiskheroes:heat_vision")) {
        return "LIGHTNING_SPEED";
    }
    return entity.hasStatusEffect("fiskheroes:eternium") ? "ETERNIUM" : null;
}

function getTierOverride(entity) {
    return entity.getData("fiskrework:dyn/shazam") ? entity.hasStatusEffect("fiskheroes:eternium") ? 5 : 9 : 0;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:arrow_catching":
        return entity.isPunching() && entity.getData("fiskrework:dyn/shazam");
    case "fiskheroes:controlled_flight":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam_timer") >= 0.8;
    case "fiskheroes:super_speed":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam") && !entity.getData("fiskheroes:flying");
    case "fiskheroes:heat_vision":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam");
    case "fiskheroes:lightning_cast":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam") && !entity.getData("fiskheroes:heat_vision");
    case "fiskheroes:leaping":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam");
    case "fiskheroes:projectile_immunity":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam");
    case "fiskheroes:fire_immunity":
        return !entity.hasStatusEffect("fiskheroes:eternium") && entity.getData("fiskrework:dyn/shazam");
    case "fiskheroes:healing_factor":
        return entity.getData("fiskrework:dyn/shazam_timer") > 0 && entity.getData("fiskrework:dyn/shazam_timer") < 1;
    case "fiskheroes:damage_weakness":
        return entity.getData("fiskrework:dyn/shazam");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "SUPER_SPEED":
            return entity.getData("fiskrework:dyn/shazam") && !entity.hasStatusEffect("fiskheroes:eternium") && !entity.getData("fiskheroes:flying");
        case "HEAT_VISION":
            return entity.getData("fiskrework:dyn/shazam") && !entity.hasStatusEffect("fiskheroes:eternium") && !(entity.isSprinting() && entity.getData("fiskheroes:flying")) && !entity.getData("fiskheroes:speed_sprinting");
        case "SHAZAM":
            return entity.getData("fiskrework:dyn/shazam_timer") == 0 || entity.getData("fiskrework:dyn/shazam_timer") == 1;
        default:
            return true;
    }
}