var landing = implement("fiskrework:external/superhero_swing_landing");

function init(hero) {
    hero.setName("Spider-Man/Raimi");
    hero.setVersion("Rework");
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("fiskrework:spider_physiology_rework", "fiskrework:web_shooters_organic_rework");
    hero.addAttribute("FALL_RESISTANCE", 11.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.0, 0);
    hero.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.4, 1);
    hero.addAttribute("STEP_HEIGHT", 0.5, 0);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("UTILITY_BELT", "key.webShooters", 1);
    hero.addKeyBind("WEB_ZIP", "key.webZip", 2);
    hero.addKeyBindFunc("func_WEB_SWINGING", webSwingingKey, "key.webSwinging", 3);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotionHold", 4);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setAttributeProfile(getAttributeProfile);
    hero.addAttributeProfile("LAND", landProfile);
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");

    hero.setTickHandler((entity, manager) => {
        if (!entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 7, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));;
        }
        else if (entity.getData("fiskheroes:dyn/superhero_landing_ticks") == 0) {
            manager.incrementData(entity, "fiskrework:dyn/sneaking_timer", 30, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));
        }
        manager.incrementData(entity, "fiskrework:dyn/perch_timer", 6, entity.getData("fiskrework:dyn/sneaking_timer") == 1);
        
        landing.tick(entity, manager);
     });
}

function webSwingingKey(player, manager) {
    var flag = player.getData("fiskheroes:web_swinging");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
    }

    manager.setDataWithNotify(player, "fiskheroes:web_swinging", !flag);
    return true;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:web_swinging":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:utility_belt_type") == -1;
    case "fiskheroes:leaping":
        return modifier.id() == "springboard" == (entity.getData("fiskheroes:ticks_since_swinging") < 5);
    case "fiskheroes:arrow_catching":
        return entity.isPunching() || entity.getData("fiskheroes:slow_motion");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "func_WEB_SWINGING":
        return entity.getHeldItem().isEmpty();
    default:
        return true;
    }
}

function landProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 22.0, 0);
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskheroes:dyn/superhero_landing_timer") > 0) {
        return "LAND";
    }
}