var landing = implement("fiskheroes:external/superhero_landing");
var super_boost = implement("fiskrework:external/super_boost_with_cooldown");

function init(hero) {
    hero.setName("hero.fiskheroes.iron_man_mk50.name");
    hero.setVersion("Rework")
    hero.setTier(8);

    hero.setChestplate("item.superhero_armor.piece.arc_reactor");

    hero.addPowers("fiskrework:mk50_nanites_rework");
    hero.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 12.0, 0);

    hero.addKeyBind("HEAT_VISION", "key.aim", -1)
    hero.addKeyBind("AIM", "key.aim", 1);
    hero.addKeyBind("SLASH", "Toggle Energy Blade", 2);
    hero.addKeyBind("IMPALE", "Toggle Nanite Katar", 2);
    hero.addKeyBind("CIRCLE", "Toggle Nanite Shield", 2);
    hero.addKeyBind("MEGA", "Toggle Large Shield", 2);
    hero.addKeyBind("ENERGY_PROJECTION", "Laser", 3);
    hero.addKeyBind("CHARGED_BEAM", "Cluster Cannons", 3);
    hero.addKeyBind("UTILITY_BELT", "Activate Missles", 4);
    hero.addKeyBind("TOGGLE_NANITE", "Cycle Nanite Formation", 4);
    hero.addKeyBind("TOGGLE_BLAST", "Toggle Crab Cannon/Repulsors", 5);
    hero.addKeyBind("NANITE_TRANSFORM", "key.naniteTransform", 5);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.setTierOverride(getTierOverride);
    hero.supplyFunction("canAim", canAim);

    hero.addAttributeProfile("INACTIVE", inactiveProfile);
    hero.addAttributeProfile("CLUSTER", clusterProfile);
    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.addAttributeProfile("IMPALE", impaleProfile);
    hero.addAttributeProfile("CIRCLE", circleProfile);
    hero.addAttributeProfile("MEGA", megaProfile);
    hero.addAttributeProfile("MEGA_BLOCK", megaBlockProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDamageProfile(getProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "ENERGY": 0.7
        }
    });

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:mk50_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:mk50_mask_close");
    hero.addSoundEvent("AIM_START", ["fiskheroes:mk50_cannon_aim", "fiskheroes:mk50_cannon_static"]);
    hero.addSoundEvent("AIM_STOP", "fiskheroes:mk50_cannon_retract");
    hero.addSoundEvent("STEP", "fiskheroes:mk50_walk");

    super_boost = super_boost.create(280, 200, 30);
    super_boost.addKeyBind(hero, "Foot Thruster")

    hero.setTickHandler((entity, manager) => {
        var flying = entity.getData("fiskheroes:flying");
        var boost = entity.getData("fiskheroes:dyn/flight_super_boost");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0 && entity.getData("fiskheroes:blade_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        landing.tick(entity, manager);

        super_boost.tick(entity, manager);
        manager.incrementData(entity, "fiskheroes:dyn/flight_super_boost_timer", 4, 14, boost > 0);

        if (!entity.isSneaking() && !entity.isOnGround() && entity.motionY() < -0.75) {
            manager.setData(entity, "fiskheroes:dyn/nanites", true);
        }
        if (!entity.isSneaking() && !entity.isOnGround() && entity.motionY() < -1.6 && entity.getData("fiskheroes:dyn/nanites") == true) {
            manager.setData(entity, "fiskheroes:flying", true);
        }
        if (entity.getData("fiskrework:dyn/slasher") || entity.getData("fiskrework:dyn/impaler")) {
            manager.setData(entity, "fiskheroes:blade", true);
        }
        if (entity.getData("fiskrework:dyn/circle") || entity.getData("fiskrework:dyn/mega")) {
            manager.setData(entity, "fiskheroes:shield", true);
        }
        
        if (!entity.getData("fiskheroes:blade")) {
            manager.setData(entity, "fiskrework:dyn/slasher", false);
            manager.setData(entity, "fiskrework:dyn/impaler", false);
        }

        if (!entity.getData("fiskheroes:shield")) {
            manager.setData(entity, "fiskrework:dyn/circle", false);
            manager.setData(entity, "fiskrework:dyn/mega", false);
        }

        if (entity.getData("fiskheroes:beam_charge") > 0) {
            manager.setData(entity, "fiskrework:dyn/slasher", false);
            manager.setData(entity, "fiskrework:dyn/impaler", false);
            manager.setData(entity, "fiskrework:dyn/circle", false);
            manager.setData(entity, "fiskrework:dyn/mega", false);
        }
    });
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/nanites") ? entity.getData("fiskheroes:shield") && entity.getData("fiskrework:dyn/mega") ? 7 : 8 : 0;
}

function inactiveProfile(profile) {
    profile.revokeAugments();
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 10.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.5, 0);
    profile.addAttribute("SPRINT_SPEED", 0.2, 1);
    profile.addAttribute("FALL_RESISTANCE", 13.5, 0);
}

function impaleProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 12.5, 0);
    profile.addAttribute("SPRINT_SPEED", 0.0, 1);
}

function circleProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 10.0, 0);
}

function megaProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 11.0, 0);
    profile.addAttribute("BASE_SPEED", -0.2, 1);
    profile.addAttribute("SPRINT_SPEED", 0.0, 1);
}

function megaBlockProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 11.0, 0);
    profile.addAttribute("BASE_SPEED", -0.65, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
    profile.addAttribute("SPRINT_SPEED", -0.20, 1);
}

function clusterProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.8, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function getProfile(entity) {
    if (!entity.getData("fiskheroes:dyn/nanites")) {
        return "INACTIVE";
    } else if (entity.getData("fiskrework:dyn/circle")) {
        return "CIRCLE";
    } else if (entity.getData("fiskrework:dyn/slasher")) {
        return "BLADE";
    } else if (entity.getData("fiskrework:dyn/impaler")) {
        return "IMPALE";
    } else if (entity.getData("fiskheroes:beam_charge") > 0 && entity.getData("fiskheroes:beam_shooting")) {
        return "CLUSTER";
    }
    return entity.getData("fiskrework:dyn/mega") ? entity.getData("fiskrework:dyn/mega") && entity.getData("fiskheroes:shield_blocking") ? "MEGA_BLOCK" : "MEGA" : null
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() != "fiskheroes:transformation" && modifier.name() != "fiskheroes:cooldown" && (!entity.getData("fiskheroes:dyn/nanites") || modifier.name() == "fiskheroes:controlled_flight" && entity.getData("fiskheroes:dyn/nanite_timer") < 1)) {
        return false;
    }

    switch (modifier.name()) {
    case "fiskheroes:energy_bolt":
        return entity.getData("fiskheroes:aimed_timer") >= 1 && !entity.getData("fiskrework:dyn/laser_switch");
    case "fiskheroes:repulsor_blast":
        return entity.getData("fiskheroes:aimed_timer") >= 1 && entity.getData("fiskrework:dyn/laser_switch");
    case "fiskheroes:blade":
        if (entity.getData("fiskheroes:aiming") || entity.getData("fiskheroes:shield") || entity.isSprinting() && entity.getData("fiskheroes:flying")) {
            return false;
        };
        switch (modifier.id()) {
        case "slash":
            return entity.getData("fiskrework:dyn/slasher");
        case "impale":
            return entity.getData("fiskrework:dyn/impaler");
        };
    case "fiskheroes:regeneration":
        return entity.getData("fiskheroes:dyn/nanites");
    case "fiskheroes:shield":
        if (entity.getData("fiskheroes:aiming") || entity.getData("fiskheroes:blade") || entity.isSprinting() && entity.getData("fiskheroes:flying") || !entity.getData("fiskrework:dyn/circle") && !entity.getData("fiskrework:dyn/mega")) {
            return false;
        }
        switch (modifier.id()) {
        case "circle":
            return entity.getData("fiskrework:dyn/circle");
        case "mega":
            return entity.getData("fiskrework:dyn/mega");
        };
    case "fiskheroes:water_breathing":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    case "fiskheroes:repulsor_blast":
        return !entity.getData("fiskheroes:heat_vision");
    default:
        return super_boost.isModifierEnabled(entity, modifier);
    }
}

function isKeyBindEnabled(entity, keyBind) {
    var bfly = entity.isSprinting() && entity.getData("fiskheroes:flying")
        if (!entity.getData("fiskheroes:dyn/nanites") && keyBind != "NANITE_TRANSFORM" || keyBind != "UTILITY_BELT" && keyBind != "AIM" && keyBind != "func_BOOST" && entity.isSprinting() && entity.getData("fiskheroes:flying")) {
            return false;
        }

        switch (keyBind) {
        case "SLASH":
            return !bfly && (!entity.getData("fiskrework:dyn/weapon_switch") && !entity.isSneaking() || entity.getData("fiskrework:dyn/slasher")) && entity.getData("fiskrework:dyn/impaler_timer") == 0;
        case "IMPALE":
            return !bfly && (!entity.getData("fiskrework:dyn/weapon_switch") && entity.isSneaking() || entity.getData("fiskrework:dyn/impaler")) && entity.getData("fiskrework:dyn/slasher_timer") == 0;
        case "CIRCLE":
            return !bfly && (entity.getData("fiskrework:dyn/weapon_switch") && !entity.isSneaking() || entity.getData("fiskrework:dyn/circle")) && entity.getData("fiskrework:dyn/mega_timer") == 0;
        case "MEGA":
            return !bfly && (entity.getData("fiskrework:dyn/weapon_switch") && entity.isSneaking() || entity.getData("fiskrework:dyn/mega")) && entity.getData("fiskrework:dyn/circle_timer") == 0;
        case "AIM":
            return entity.getData("fiskheroes:dyn/nanites") && !entity.getData("fiskheroes:energy_projection") && entity.getData("fiskheroes:utility_belt_type") == -1;
        case "HEAT_VISION":
            return entity.getData("fiskheroes:aiming") && entity.getData("fiskrework:dyn/laser_switch");
        case "ENERGY_PROJECTION":
            return entity.getHeldItem().isEmpty() && (!entity.isSneaking() || entity.getData("fiskheroes:energy_projection")) && entity.getData("fiskheroes:utility_belt_type") == -1 && !(entity.isSprinting() && entity.getData("fiskheroes:flying")) && !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:blade") && !entity.getData("fiskheroes:shield");
        case "CHARGED_BEAM":
            return entity.isSneaking() && !entity.getData("fiskheroes:energy_projection");
        case "UTILITY_BELT":
            return !entity.isSneaking();
        case "TOGGLE_NANITE":
            return entity.isSneaking() && !(entity.getData("fiskheroes:blade") || entity.getData("fiskheroes:shield"));
        case "TOGGLE_BLAST":
            return entity.isSneaking();
        case "NANITE_TRANSFORM":
            return entity.getData("fiskheroes:mask_open_timer") == 0 && entity.getData("fiskheroes:dyn/flight_super_boost") == 0 && (!entity.getData("fiskheroes:dyn/nanites") || !entity.isSneaking());
        default:
            return super_boost.isKeyBindEnabled(entity, keyBind);
        }
}

function hasProperty(entity, property) {
    switch (property) {
    case "MASK_TOGGLE":
        return entity.getData("fiskheroes:dyn/nanite_timer") == 1;
    case "BREATHE_SPACE":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return false;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:dyn/nanites");
}
