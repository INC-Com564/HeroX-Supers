extend("fiskrework:spider_man_ps4_rework");
loadTextures({
    "layer1": "fiskrework:spider_man_ps4_undies_layer1",
    "layer2": "fiskrework:spider_man_ps4_undies_layer2"
});

function init(renderer) {
    renderer.setItemIcons("spider_man_ps4_rework_0", "%s_1", "%s_2", "%s_3");
}